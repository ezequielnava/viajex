from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse
from rest_framework_simplejwt.tokens import UntypedToken
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from django.contrib.auth import get_user_model
import jwt
from django.conf import settings

User = get_user_model()


class JWTAuthenticationMiddleware(MiddlewareMixin):
    """
    Middleware para autenticación JWT en WebSockets
    """
    
    def process_request(self, request):
        # Solo procesar para WebSocket connections
        if not request.path.startswith('/ws/'):
            return None
        
        # Obtener token del query string o headers
        token = request.GET.get('token') or request.META.get('HTTP_AUTHORIZATION')
        
        if token:
            try:
                if token.startswith('Bearer '):
                    token = token[7:]
                
                # Validar token
                UntypedToken(token)
                
                # Decodificar token para obtener user_id
                decoded_token = jwt.decode(
                    token, 
                    settings.SECRET_KEY, 
                    algorithms=['HS256']
                )
                user_id = decoded_token.get('user_id')
                
                if user_id:
                    try:
                        user = User.objects.get(id=user_id)
                        request.user = user
                    except User.DoesNotExist:
                        pass
                        
            except (InvalidToken, TokenError, jwt.DecodeError):
                pass
        
        return None


class CorsMiddleware(MiddlewareMixin):
    """
    Middleware personalizado para CORS
    """
    
    def process_response(self, request, response):
        response["Access-Control-Allow-Origin"] = "*"
        response["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        return response
