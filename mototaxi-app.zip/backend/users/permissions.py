from rest_framework import permissions


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Permiso personalizado para permitir solo a los propietarios editar sus objetos
    """
    
    def has_object_permission(self, request, view, obj):
        # Permisos de lectura para cualquier request
        if request.method in permissions.SAFE_METHODS:
            return True
        
        # Permisos de escritura solo para el propietario del objeto
        return obj == request.user


class IsDriverOrReadOnly(permissions.BasePermission):
    """
    Permiso personalizado para conductores
    """
    
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        
        return (request.user.is_authenticated and 
                hasattr(request.user, 'driver_profile'))


class IsPassengerOrDriver(permissions.BasePermission):
    """
    Permiso para viajes - solo pasajero o conductor del viaje
    """
    
    def has_object_permission(self, request, view, obj):
        return (obj.passenger == request.user or 
                (hasattr(request.user, 'driver_profile') and 
                 obj.driver == request.user.driver_profile))


class IsVerifiedDriver(permissions.BasePermission):
    """
    Permiso para conductores verificados
    """
    
    def has_permission(self, request, view):
        return (request.user.is_authenticated and 
                hasattr(request.user, 'driver_profile') and
                request.user.driver_profile.is_verified)
