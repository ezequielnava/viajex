from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from drivers.models import Driver
from decimal import Decimal

User = get_user_model()


class Command(BaseCommand):
    help = 'Crear usuarios de prueba para desarrollo'
    
    def handle(self, *args, **options):
        # Crear usuario pasajero de prueba
        passenger, created = User.objects.get_or_create(
            username='passenger_test',
            defaults={
                'email': 'passenger@test.com',
                'first_name': 'Juan',
                'last_name': 'Pérez',
                'user_type': 'passenger',
                'phone_number': '+584121234567',
                'is_verified': True,
                'current_latitude': Decimal('10.4806'),
                'current_longitude': Decimal('-66.9036'),
            }
        )
        if created:
            passenger.set_password('testpass123')
            passenger.save()
            self.stdout.write(
                self.style.SUCCESS(f'Usuario pasajero creado: {passenger.username}')
            )
        
        # Crear usuario conductor de prueba
        driver_user, created = User.objects.get_or_create(
            username='driver_test',
            defaults={
                'email': 'driver@test.com',
                'first_name': 'Carlos',
                'last_name': 'González',
                'user_type': 'driver',
                'phone_number': '+584129876543',
                'is_verified': True,
                'current_latitude': Decimal('10.4906'),
                'current_longitude': Decimal('-66.8936'),
            }
        )
        if created:
            driver_user.set_password('testpass123')
            driver_user.save()
            self.stdout.write(
                self.style.SUCCESS(f'Usuario conductor creado: {driver_user.username}')
            )
            
            # Crear perfil de conductor
            driver_profile, created = Driver.objects.get_or_create(
                user=driver_user,
                defaults={
                    'vehicle_type': 'motorcycle',
                    'vehicle_brand': 'Honda',
                    'vehicle_model': 'CB125',
                    'vehicle_year': 2020,
                    'vehicle_color': 'Rojo',
                    'license_plate': 'ABC123',
                    'driver_license': 'V12345678',
                    'vehicle_registration': 'REG123456',
                    'insurance_policy': 'INS789012',
                    'is_verified': True,
                    'is_available': True,
                    'status': 'online',
                }
            )
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Perfil de conductor creado para: {driver_user.username}')
                )
        
        # Crear superusuario si no existe
        if not User.objects.filter(is_superuser=True).exists():
            admin_user = User.objects.create_superuser(
                username='admin',
                email='admin@mototaxi.com',
                password='admin123',
                first_name='Admin',
                last_name='Sistema'
            )
            self.stdout.write(
                self.style.SUCCESS(f'Superusuario creado: {admin_user.username}')
            )
        
        self.stdout.write(
            self.style.SUCCESS('Usuarios de prueba creados exitosamente!')
        )
