from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.db.models import Avg
from .models import User, UserRating
from .serializers import (
    UserRegistrationSerializer, UserLoginSerializer, UserProfileSerializer,
    UserLocationSerializer, UserRatingSerializer
)


class UserRegistrationView(APIView):
    """
    Vista para el registro de usuarios
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            return Response({
                'message': 'Usuario registrado exitosamente',
                'user': UserProfileSerializer(user).data,
                'tokens': {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                }
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLoginView(APIView):
    """
    Vista para el inicio de sesión
    """
    permission_classes = [permissions.AllowAny]
    
    def post(self, request):
        serializer = UserLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            refresh = RefreshToken.for_user(user)
            return Response({
                'message': 'Inicio de sesión exitoso',
                'user': UserProfileSerializer(user).data,
                'tokens': {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                }
            }, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserProfileView(APIView):
    """
    Vista para obtener y actualizar el perfil del usuario
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data)
    
    def put(self, request):
        serializer = UserProfileSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                'message': 'Perfil actualizado exitosamente',
                'user': serializer.data
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLocationUpdateView(APIView):
    """
    Vista para actualizar la ubicación del usuario
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def put(self, request):
        serializer = UserLocationSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                'message': 'Ubicación actualizada exitosamente',
                'location': serializer.data
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserViewSet(viewsets.ModelViewSet):
    """
    ViewSet para operaciones CRUD de usuarios
    """
    queryset = User.objects.all()
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        # Los usuarios solo pueden ver su propio perfil
        if self.request.user.is_staff:
            return User.objects.all()
        return User.objects.filter(id=self.request.user.id)
    
    @action(detail=True, methods=['get'])
    def ratings(self, request, pk=None):
        """Obtener calificaciones de un usuario"""
        user = self.get_object()
        ratings = UserRating.objects.filter(rated_user=user)
        serializer = UserRatingSerializer(ratings, many=True)
        return Response(serializer.data)


class UserRatingViewSet(viewsets.ModelViewSet):
    """
    ViewSet para las calificaciones de usuarios
    """
    queryset = UserRating.objects.all()
    serializer_class = UserRatingSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def perform_create(self, serializer):
        serializer.save(rater=self.request.user)
        
        # Actualizar promedio de calificación del usuario calificado
        rated_user = serializer.validated_data['rated_user']
        avg_rating = UserRating.objects.filter(rated_user=rated_user).aggregate(
            avg=Avg('rating')
        )['avg']
        total_ratings = UserRating.objects.filter(rated_user=rated_user).count()
        
        rated_user.average_rating = round(avg_rating, 2) if avg_rating else 0
        rated_user.total_ratings = total_ratings
        rated_user.save()
    
    def get_queryset(self):
        # Filtrar por usuario si se especifica
        queryset = UserRating.objects.all()
        user_id = self.request.query_params.get('user_id', None)
        if user_id is not None:
            queryset = queryset.filter(rated_user_id=user_id)
        return queryset
