from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from .models import User, UserRating


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """
    Admin personalizado para el modelo User
    """
    list_display = [
        'username', 'email', 'first_name', 'last_name', 
        'user_type', 'is_verified', 'average_rating', 'is_active'
    ]
    list_filter = [
        'user_type', 'is_verified', 'is_active', 'is_staff', 'date_joined'
    ]
    search_fields = ['username', 'email', 'first_name', 'last_name', 'phone_number']
    ordering = ['-date_joined']
    
    # Campos adicionales en el formulario
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Información Adicional', {
            'fields': (
                'phone_number', 'profile_picture', 'user_type', 
                'is_verified', 'date_of_birth'
            )
        }),
        ('Ubicación', {
            'fields': ('current_latitude', 'current_longitude')
        }),
        ('Calificaciones', {
            'fields': ('average_rating', 'total_ratings'),
            'classes': ('collapse',)
        }),
    )
    
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('Información Adicional', {
            'fields': (
                'email', 'first_name', 'last_name', 'phone_number', 
                'user_type', 'date_of_birth'
            )
        }),
    )
    
    readonly_fields = ['average_rating', 'total_ratings', 'date_joined', 'last_login']
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related()


@admin.register(UserRating)
class UserRatingAdmin(admin.ModelAdmin):
    """
    Admin para calificaciones de usuarios
    """
    list_display = [
        'rater', 'rated_user', 'rating', 'trip', 'created_at'
    ]
    list_filter = ['rating', 'created_at']
    search_fields = [
        'rater__username', 'rated_user__username', 
        'trip__trip_id', 'comment'
    ]
    ordering = ['-created_at']
    readonly_fields = ['created_at']
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            'rater', 'rated_user', 'trip'
        )
