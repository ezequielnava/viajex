from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.db.models import Avg
from .models import User, UserRating


@receiver(post_save, sender=UserRating)
def update_user_rating_on_save(sender, instance, created, **kwargs):
    """
    Actualizar calificación promedio cuando se crea o actualiza una calificación
    """
    if created:
        update_user_average_rating(instance.rated_user)


@receiver(post_delete, sender=UserRating)
def update_user_rating_on_delete(sender, instance, **kwargs):
    """
    Actualizar calificación promedio cuando se elimina una calificación
    """
    update_user_average_rating(instance.rated_user)


def update_user_average_rating(user):
    """
    Función auxiliar para actualizar la calificación promedio de un usuario
    """
    ratings = UserRating.objects.filter(rated_user=user)
    
    if ratings.exists():
        avg_rating = ratings.aggregate(avg=Avg('rating'))['avg']
        user.average_rating = round(avg_rating, 2)
        user.total_ratings = ratings.count()
    else:
        user.average_rating = 0.00
        user.total_ratings = 0
    
    user.save(update_fields=['average_rating', 'total_ratings'])


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """
    Realizar acciones adicionales cuando se crea un usuario
    """
    if created:
        # Aquí se pueden agregar acciones adicionales como:
        # - Enviar email de bienvenida
        # - Crear configuraciones por defecto
        # - Registrar en sistemas de analytics
        pass
