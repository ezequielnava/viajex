from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags


def send_welcome_email(user):
    """
    Enviar email de bienvenida a nuevo usuario
    """
    subject = 'Bienvenido a MotoTaxi'
    html_message = render_to_string('emails/welcome.html', {
        'user': user,
        'app_name': 'MotoTaxi'
    })
    plain_message = strip_tags(html_message)
    
    send_mail(
        subject,
        plain_message,
        settings.DEFAULT_FROM_EMAIL,
        [user.email],
        html_message=html_message,
        fail_silently=True,
    )


def send_verification_email(user):
    """
    Enviar email de verificación
    """
    # Implementar lógica de verificación por email
    pass


def send_driver_approval_email(driver):
    """
    Enviar email de aprobación de conductor
    """
    subject = 'Tu cuenta de conductor ha sido aprobada'
    html_message = render_to_string('emails/driver_approved.html', {
        'driver': driver,
        'app_name': 'MotoTaxi'
    })
    plain_message = strip_tags(html_message)
    
    send_mail(
        subject,
        plain_message,
        settings.DEFAULT_FROM_EMAIL,
        [driver.user.email],
        html_message=html_message,
        fail_silently=True,
    )
