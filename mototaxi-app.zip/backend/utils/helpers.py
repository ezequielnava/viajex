import uuid
import hashlib
from decimal import Decimal
from django.utils import timezone


def generate_trip_id():
    """
    Generar ID único para viaje
    """
    return str(uuid.uuid4())


def generate_reference_number():
    """
    Generar número de referencia para pagos
    """
    timestamp = str(int(timezone.now().timestamp()))
    random_uuid = str(uuid.uuid4())[:8]
    return f"REF{timestamp}{random_uuid}".upper()


def calculate_percentage(value, percentage):
    """
    Calcular porcentaje de un valor
    """
    return Decimal(str(value)) * Decimal(str(percentage)) / Decimal('100')


def format_currency(amount, currency='USD'):
    """
    Formatear cantidad como moneda
    """
    if currency == 'USD':
        return f"${amount:.2f}"
    elif currency == 'VES':
        return f"Bs. {amount:.2f}"
    else:
        return f"{amount:.2f} {currency}"


def hash_phone_number(phone_number):
    """
    Hash de número de teléfono para privacidad
    """
    return hashlib.sha256(phone_number.encode()).hexdigest()[:16]


def validate_phone_number(phone_number):
    """
    Validar formato de número de teléfono venezolano
    """
    import re
    
    # Patrón para números venezolanos
    pattern = r'^\+58(4[0-9]{8}|2[0-9]{8})$'
    return bool(re.match(pattern, phone_number))


def calculate_eta(distance_km, average_speed_kmh=25):
    """
    Calcular tiempo estimado de llegada
    """
    if distance_km <= 0:
        return 0
    
    hours = distance_km / average_speed_kmh
    minutes = int(hours * 60)
    
    # Agregar tiempo base por tráfico/paradas
    base_time = 5  # 5 minutos base
    
    return minutes + base_time
