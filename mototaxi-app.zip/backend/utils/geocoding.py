import requests
from django.conf import settings


class GeocodingService:
    """
    Servicio para geocodificación usando Google Maps API
    """
    
    @staticmethod
    def get_address_from_coordinates(latitude, longitude):
        """
        Obtener dirección desde coordenadas (geocodificación inversa)
        """
        if not settings.GOOGLE_MAPS_API_KEY:
            return f"Lat: {latitude}, Lng: {longitude}"
        
        try:
            url = 'https://maps.googleapis.com/maps/api/geocode/json'
            params = {
                'latlng': f'{latitude},{longitude}',
                'key': settings.GOOGLE_MAPS_API_KEY,
                'language': 'es'
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            if data['status'] == 'OK' and data['results']:
                return data['results'][0]['formatted_address']
            
        except Exception as e:
            print(f"Error en geocodificación inversa: {e}")
        
        return f"Lat: {latitude}, Lng: {longitude}"
    
    @staticmethod
    def get_coordinates_from_address(address):
        """
        Obtener coordenadas desde dirección (geocodificación)
        """
        if not settings.GOOGLE_MAPS_API_KEY:
            return None
        
        try:
            url = 'https://maps.googleapis.com/maps/api/geocode/json'
            params = {
                'address': address,
                'key': settings.GOOGLE_MAPS_API_KEY,
                'language': 'es'
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            if data['status'] == 'OK' and data['results']:
                location = data['results'][0]['geometry']['location']
                return {
                    'latitude': location['lat'],
                    'longitude': location['lng']
                }
            
        except Exception as e:
            print(f"Error en geocodificación: {e}")
        
        return None
