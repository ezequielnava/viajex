import json
import requests
from django.conf import settings
from django.core.mail import send_mail
from django.template.loader import render_to_string
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync


class NotificationService:
    """
    Servicio para envío de notificaciones
    """
    
    @staticmethod
    def send_push_notification(user, title, body, data=None):
        """
        Enviar notificación push (simulado - se integraría con FCM)
        """
        # Aquí se integraría con Firebase Cloud Messaging
        notification_data = {
            'title': title,
            'body': body,
            'data': data or {},
            'user_id': user.id
        }
        
        # Por ahora, solo registramos la notificación
        print(f"Push notification to {user.username}: {title} - {body}")
        
        return notification_data
    
    @staticmethod
    def send_websocket_notification(user, notification_type, data):
        """
        Enviar notificación por WebSocket
        """
        channel_layer = get_channel_layer()
        
        if channel_layer:
            async_to_sync(channel_layer.group_send)(
                f"user_{user.id}",
                {
                    'type': 'notification_message',
                    'notification_type': notification_type,
                    'data': data
                }
            )
    
    @staticmethod
    def send_trip_request_notification(driver, trip):
        """
        Notificar a conductor sobre nueva solicitud de viaje
        """
        title = "Nueva solicitud de viaje"
        body = f"Viaje desde {trip.origin_address} a {trip.destination_address}"
        
        data = {
            'trip_id': str(trip.trip_id),
            'passenger_name': trip.passenger.get_full_name(),
            'origin': trip.origin_address,
            'destination': trip.destination_address,
            'estimated_cost': str(trip.estimated_cost)
        }
        
        # Enviar push notification
        NotificationService.send_push_notification(driver.user, title, body, data)
        
        # Enviar por WebSocket
        NotificationService.send_websocket_notification(
            driver.user, 'trip_request', data
        )
    
    @staticmethod
    def send_trip_accepted_notification(passenger, trip):
        """
        Notificar a pasajero que su viaje fue aceptado
        """
        title = "Viaje aceptado"
        body = f"Tu conductor {trip.driver.user.get_full_name()} está en camino"
        
        data = {
            'trip_id': str(trip.trip_id),
            'driver_name': trip.driver.user.get_full_name(),
            'driver_phone': trip.driver.user.phone_number,
            'vehicle_info': f"{trip.driver.vehicle_brand} {trip.driver.vehicle_model}",
            'license_plate': trip.driver.license_plate
        }
        
        NotificationService.send_push_notification(passenger, title, body, data)
        NotificationService.send_websocket_notification(passenger, 'trip_accepted', data)
    
    @staticmethod
    def send_driver_arrived_notification(passenger, trip):
        """
        Notificar que el conductor llegó
        """
        title = "Tu conductor ha llegado"
        body = f"{trip.driver.user.get_full_name()} te está esperando"
        
        data = {
            'trip_id': str(trip.trip_id),
            'driver_name': trip.driver.user.get_full_name(),
            'license_plate': trip.driver.license_plate
        }
        
        NotificationService.send_push_notification(passenger, title, body, data)
        NotificationService.send_websocket_notification(passenger, 'driver_arrived', data)
    
    @staticmethod
    def send_trip_started_notification(passenger, trip):
        """
        Notificar que el viaje comenzó
        """
        title = "Viaje iniciado"
        body = "Tu viaje ha comenzado. ¡Buen viaje!"
        
        data = {
            'trip_id': str(trip.trip_id),
            'estimated_arrival': trip.estimated_duration_minutes
        }
        
        NotificationService.send_push_notification(passenger, title, body, data)
        NotificationService.send_websocket_notification(passenger, 'trip_started', data)
    
    @staticmethod
    def send_trip_completed_notification(passenger, trip):
        """
        Notificar que el viaje se completó
        """
        title = "Viaje completado"
        body = f"Has llegado a tu destino. Costo: ${trip.final_cost}"
        
        data = {
            'trip_id': str(trip.trip_id),
            'final_cost': str(trip.final_cost),
            'duration': trip.duration_minutes
        }
        
        NotificationService.send_push_notification(passenger, title, body, data)
        NotificationService.send_websocket_notification(passenger, 'trip_completed', data)
    
    @staticmethod
    def send_trip_cancelled_notification(user, trip):
        """
        Notificar cancelación de viaje
        """
        title = "Viaje cancelado"
        body = "Tu viaje ha sido cancelado"
        
        data = {
            'trip_id': str(trip.trip_id),
            'reason': 'Cancelado por el sistema'
        }
        
        NotificationService.send_push_notification(user, title, body, data)
        NotificationService.send_websocket_notification(user, 'trip_cancelled', data)
    
    @staticmethod
    def send_email_notification(user, subject, template, context):
        """
        Enviar notificación por email
        """
        html_message = render_to_string(f'emails/{template}.html', context)
        
        send_mail(
            subject,
            '',
            settings.DEFAULT_FROM_EMAIL,
            [user.email],
            html_message=html_message,
            fail_silently=True
        )
