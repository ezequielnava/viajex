from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import Distance
from django.utils import timezone
from django.db.models import Q
from .models import Driver, DriverDocument
from .serializers import (
    DriverRegistrationSerializer, DriverProfileSerializer,
    DriverLocationSerializer, AvailableDriverSerializer,
    DriverDocumentSerializer, DriverStatusSerializer
)
from users.models import User


class DriverRegistrationView(APIView):
    """
    Vista para el registro de conductores
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        # Verificar que el usuario no sea ya conductor
        if hasattr(request.user, 'driver_profile'):
            return Response({
                'error': 'El usuario ya tiene un perfil de conductor'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Cambiar tipo de usuario a conductor
        request.user.user_type = 'driver'
        request.user.save()
        
        serializer = DriverRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            driver = serializer.save(user=request.user)
            return Response({
                'message': 'Conductor registrado exitosamente',
                'driver': DriverProfileSerializer(driver).data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AvailableDriversView(APIView):
    """
    Vista para obtener conductores disponibles cerca de una ubicación
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        lat = request.query_params.get('latitude')
        lng = request.query_params.get('longitude')
        radius = float(request.query_params.get('radius', 5))  # Radio en km, default 5km
        
        if not lat or not lng:
            return Response({
                'error': 'Se requieren parámetros latitude y longitude'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            lat = float(lat)
            lng = float(lng)
        except ValueError:
            return Response({
                'error': 'Coordenadas inválidas'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Buscar conductores disponibles
        available_drivers = Driver.objects.filter(
            status='online',
            is_available=True,
            is_verified=True,
            user__current_latitude__isnull=False,
            user__current_longitude__isnull=False
        ).select_related('user')
        
        # Filtrar por distancia (implementación básica)
        nearby_drivers = []
        for driver in available_drivers:
            driver_lat = float(driver.user.current_latitude)
            driver_lng = float(driver.user.current_longitude)
            
            # Cálculo básico de distancia (se puede mejorar con PostGIS)
            distance = ((lat - driver_lat) ** 2 + (lng - driver_lng) ** 2) ** 0.5
            if distance <= radius / 111:  # Aproximación: 1 grado ≈ 111 km
                nearby_drivers.append(driver)
        
        serializer = AvailableDriverSerializer(nearby_drivers, many=True)
        return Response({
            'drivers': serializer.data,
            'count': len(nearby_drivers)
        })


class DriverStatusUpdateView(APIView):
    """
    Vista para actualizar el estado del conductor
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def put(self, request):
        try:
            driver = request.user.driver_profile
        except Driver.DoesNotExist:
            return Response({
                'error': 'Usuario no es conductor'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = DriverStatusSerializer(driver, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save(last_location_update=timezone.now())
            return Response({
                'message': 'Estado actualizado exitosamente',
                'driver': DriverProfileSerializer(driver).data
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class DriverViewSet(viewsets.ModelViewSet):
    """
    ViewSet para operaciones CRUD de conductores
    """
    serializer_class = DriverProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_staff:
            return Driver.objects.all()
        # Los conductores solo pueden ver su propio perfil
        return Driver.objects.filter(user=self.request.user)
    
    @action(detail=False, methods=['get'])
    def me(self, request):
        """Obtener perfil del conductor actual"""
        try:
            driver = request.user.driver_profile
            serializer = self.get_serializer(driver)
            return Response(serializer.data)
        except Driver.DoesNotExist:
            return Response({
                'error': 'Usuario no es conductor'
            }, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=True, methods=['get'])
    def trips(self, request, pk=None):
        """Obtener viajes del conductor"""
        driver = self.get_object()
        trips = driver.driver_trips.all()[:20]  # Últimos 20 viajes
        from trips.serializers import TripListSerializer
        serializer = TripListSerializer(trips, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def earnings(self, request, pk=None):
        """Obtener estadísticas de ganancias"""
        driver = self.get_object()
        from django.db.models import Sum, Count
        from trips.models import Trip
        
        stats = Trip.objects.filter(
            driver=driver,
            status='completed'
        ).aggregate(
            total_earnings=Sum('final_cost'),
            total_trips=Count('id')
        )
        
        return Response({
            'total_earnings': stats['total_earnings'] or 0,
            'total_trips': stats['total_trips'] or 0,
            'average_per_trip': (stats['total_earnings'] or 0) / max(stats['total_trips'] or 1, 1)
        })


class DriverDocumentViewSet(viewsets.ModelViewSet):
    """
    ViewSet para documentos de conductores
    """
    queryset = DriverDocument.objects.all()
    serializer_class = DriverDocumentSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        if self.request.user.is_staff:
            return DriverDocument.objects.all()
        # Solo documentos del conductor actual
        try:
            driver = self.request.user.driver_profile
            return DriverDocument.objects.filter(driver=driver)
        except Driver.DoesNotExist:
            return DriverDocument.objects.none()
    
    def perform_create(self, serializer):
        driver = self.request.user.driver_profile
        serializer.save(driver=driver)
