from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Driver, DriverDocument


@receiver(post_save, sender=DriverDocument)
def check_driver_verification_status(sender, instance, **kwargs):
    """
    Verificar si el conductor puede ser verificado automáticamente
    """
    driver = instance.driver
    
    # Verificar si todos los documentos requeridos están verificados
    required_docs = ['id_card', 'criminal_record', 'medical_certificate']
    verified_docs = DriverDocument.objects.filter(
        driver=driver,
        document_type__in=required_docs,
        is_verified=True
    ).count()
    
    # También verificar documentos principales del modelo Driver
    has_main_docs = all([
        driver.driver_license_image,
        driver.vehicle_registration_image,
        driver.insurance_image
    ])
    
    # Si tiene todos los documentos, marcar como verificado
    if verified_docs >= len(required_docs) and has_main_docs:
        driver.is_verified = True
        driver.save(update_fields=['is_verified'])


@receiver(post_save, sender=Driver)
def update_user_type_on_driver_creation(sender, instance, created, **kwargs):
    """
    Asegurar que el tipo de usuario sea 'driver' cuando se crea un perfil de conductor
    """
    if created and instance.user.user_type != 'driver':
        instance.user.user_type = 'driver'
        instance.user.save(update_fields=['user_type'])
