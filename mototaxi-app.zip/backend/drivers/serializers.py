from rest_framework import serializers
from .models import Driver, DriverDocument
from users.serializers import UserProfileSerializer


class DriverRegistrationSerializer(serializers.ModelSerializer):
    """
    Serializer para el registro de conductores
    """
    class Meta:
        model = Driver
        fields = [
            'vehicle_type', 'vehicle_brand', 'vehicle_model', 'vehicle_year',
            'vehicle_color', 'license_plate', 'driver_license',
            'driver_license_image', 'vehicle_registration', 'vehicle_registration_image',
            'insurance_policy', 'insurance_image'
        ]


class DriverProfileSerializer(serializers.ModelSerializer):
    """
    Serializer para el perfil completo del conductor
    """
    user = UserProfileSerializer(read_only=True)
    full_name = serializers.CharField(read_only=True)
    
    class Meta:
        model = Driver
        fields = [
            'id', 'user', 'full_name', 'vehicle_type', 'vehicle_brand',
            'vehicle_model', 'vehicle_year', 'vehicle_color', 'license_plate',
            'status', 'is_available', 'is_verified', 'total_trips',
            'total_earnings', 'created_at', 'updated_at', 'last_location_update'
        ]
        read_only_fields = [
            'id', 'user', 'full_name', 'is_verified', 'total_trips',
            'total_earnings', 'created_at', 'updated_at', 'last_location_update'
        ]


class DriverLocationSerializer(serializers.ModelSerializer):
    """
    Serializer para la ubicación del conductor (usa el modelo User)
    """
    class Meta:
        model = Driver
        fields = ['user']
    
    def to_representation(self, instance):
        return {
            'driver_id': instance.id,
            'latitude': instance.user.current_latitude,
            'longitude': instance.user.current_longitude,
            'last_update': instance.last_location_update
        }


class AvailableDriverSerializer(serializers.ModelSerializer):
    """
    Serializer para conductores disponibles (información básica)
    """
    user_name = serializers.CharField(source='user.get_full_name', read_only=True)
    user_rating = serializers.DecimalField(source='user.average_rating', max_digits=3, decimal_places=2, read_only=True)
    latitude = serializers.DecimalField(source='user.current_latitude', max_digits=9, decimal_places=6, read_only=True)
    longitude = serializers.DecimalField(source='user.current_longitude', max_digits=9, decimal_places=6, read_only=True)
    
    class Meta:
        model = Driver
        fields = [
            'id', 'user_name', 'user_rating', 'vehicle_type',
            'vehicle_brand', 'vehicle_model', 'vehicle_color',
            'license_plate', 'latitude', 'longitude', 'total_trips'
        ]


class DriverDocumentSerializer(serializers.ModelSerializer):
    """
    Serializer para documentos adicionales del conductor
    """
    class Meta:
        model = DriverDocument
        fields = [
            'id', 'document_type', 'document_number', 'document_image',
            'is_verified', 'uploaded_at'
        ]
        read_only_fields = ['id', 'is_verified', 'uploaded_at']


class DriverStatusSerializer(serializers.ModelSerializer):
    """
    Serializer para actualizar el estado del conductor
    """
    class Meta:
        model = Driver
        fields = ['status', 'is_available']
