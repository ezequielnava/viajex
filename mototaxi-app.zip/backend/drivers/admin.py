from django.contrib import admin
from django.utils.html import format_html
from .models import Driver, DriverDocument


@admin.register(Driver)
class DriverAdmin(admin.ModelAdmin):
    """
    Admin personalizado para conductores
    """
    list_display = [
        'user', 'license_plate', 'vehicle_info', 'status', 
        'is_verified', 'total_trips', 'total_earnings'
    ]
    list_filter = [
        'status', 'is_verified', 'is_available', 'vehicle_type', 'created_at'
    ]
    search_fields = [
        'user__username', 'user__email', 'license_plate', 
        'driver_license', 'vehicle_brand', 'vehicle_model'
    ]
    ordering = ['-created_at']
    
    fieldsets = (
        ('Información del Conductor', {
            'fields': ('user', 'is_verified', 'status', 'is_available')
        }),
        ('Información del Vehículo', {
            'fields': (
                'vehicle_type', 'vehicle_brand', 'vehicle_model', 
                'vehicle_year', 'vehicle_color', 'license_plate'
            )
        }),
        ('Documentos', {
            'fields': (
                'driver_license', 'driver_license_image',
                'vehicle_registration', 'vehicle_registration_image',
                'insurance_policy', 'insurance_image'
            )
        }),
        ('Estadísticas', {
            'fields': ('total_trips', 'total_earnings'),
            'classes': ('collapse',)
        }),
    )
    
    readonly_fields = ['total_trips', 'total_earnings', 'created_at', 'updated_at']
    
    def vehicle_info(self, obj):
        return f"{obj.vehicle_brand} {obj.vehicle_model} ({obj.vehicle_year})"
    vehicle_info.short_description = 'Vehículo'
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')
    
    actions = ['verify_drivers', 'unverify_drivers']
    
    def verify_drivers(self, request, queryset):
        updated = queryset.update(is_verified=True)
        self.message_user(request, f'{updated} conductores verificados.')
    verify_drivers.short_description = 'Verificar conductores seleccionados'
    
    def unverify_drivers(self, request, queryset):
        updated = queryset.update(is_verified=False)
        self.message_user(request, f'{updated} conductores desverificados.')
    unverify_drivers.short_description = 'Desverificar conductores seleccionados'


@admin.register(DriverDocument)
class DriverDocumentAdmin(admin.ModelAdmin):
    """
    Admin para documentos de conductores
    """
    list_display = [
        'driver', 'document_type', 'document_number', 
        'is_verified', 'uploaded_at'
    ]
    list_filter = ['document_type', 'is_verified', 'uploaded_at']
    search_fields = [
        'driver__user__username', 'document_number', 'document_type'
    ]
    ordering = ['-uploaded_at']
    readonly_fields = ['uploaded_at']
    
    actions = ['verify_documents', 'unverify_documents']
    
    def verify_documents(self, request, queryset):
        updated = queryset.update(is_verified=True)
        self.message_user(request, f'{updated} documentos verificados.')
    verify_documents.short_description = 'Verificar documentos seleccionados'
    
    def unverify_documents(self, request, queryset):
        updated = queryset.update(is_verified=False)
        self.message_user(request, f'{updated} documentos desverificados.')
    unverify_documents.short_description = 'Desverificar documentos seleccionados'
