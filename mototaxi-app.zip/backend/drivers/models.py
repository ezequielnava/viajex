from django.db import models
from django.core.validators import RegexValidator
from users.models import User


class Driver(models.Model):
    """
    Modelo para conductores con información específica del vehículo y documentos
    """
    VEHICLE_TYPE_CHOICES = [
        ('motorcycle', 'Motocicleta'),
        ('scooter', 'Scooter'),
    ]
    
    STATUS_CHOICES = [
        ('offline', 'Desconectado'),
        ('online', 'En línea'),
        ('busy', 'Ocupado'),
    ]
    
    # Relación con usuario
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='driver_profile')
    
    # Información del vehículo
    vehicle_type = models.CharField(max_length=20, choices=VEHICLE_TYPE_CHOICES, default='motorcycle')
    vehicle_brand = models.CharField(max_length=50)
    vehicle_model = models.CharField(max_length=50)
    vehicle_year = models.PositiveIntegerField()
    vehicle_color = models.CharField(max_length=30)
    license_plate = models.CharField(max_length=10, unique=True)
    
    # Documentos
    driver_license = models.CharField(max_length=20, unique=True)
    driver_license_image = models.ImageField(upload_to='driver_docs/licenses/')
    vehicle_registration = models.CharField(max_length=20)
    vehicle_registration_image = models.ImageField(upload_to='driver_docs/registrations/')
    insurance_policy = models.CharField(max_length=30)
    insurance_image = models.ImageField(upload_to='driver_docs/insurance/')
    
    # Estado y disponibilidad
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='offline')
    is_available = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    
    # Estadísticas
    total_trips = models.PositiveIntegerField(default=0)
    total_earnings = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_location_update = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Conductor: {self.user.username} - {self.license_plate}"
    
    @property
    def full_name(self):
        return f"{self.user.first_name} {self.user.last_name}"
    
    class Meta:
        db_table = 'drivers'
        verbose_name = 'Conductor'
        verbose_name_plural = 'Conductores'


class DriverDocument(models.Model):
    """
    Modelo para documentos adicionales del conductor
    """
    DOCUMENT_TYPE_CHOICES = [
        ('id_card', 'Cédula de Identidad'),
        ('criminal_record', 'Antecedentes Penales'),
        ('medical_certificate', 'Certificado Médico'),
        ('other', 'Otro'),
    ]
    
    driver = models.ForeignKey(Driver, on_delete=models.CASCADE, related_name='additional_documents')
    document_type = models.CharField(max_length=20, choices=DOCUMENT_TYPE_CHOICES)
    document_number = models.CharField(max_length=30, blank=True)
    document_image = models.ImageField(upload_to='driver_docs/additional/')
    is_verified = models.BooleanField(default=False)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'driver_documents'
        verbose_name = 'Documento de Conductor'
        verbose_name_plural = 'Documentos de Conductores'
    
    def __str__(self):
        return f"{self.driver.user.username} - {self.get_document_type_display()}"
