from rest_framework import serializers
from .models import Trip, TripLocation, TripCancellation
from drivers.serializers import AvailableDriverSerializer
from users.serializers import UserProfileSerializer


class TripRequestSerializer(serializers.ModelSerializer):
    """
    Serializer para solicitar un nuevo viaje
    """
    class Meta:
        model = Trip
        fields = [
            'origin_address', 'origin_latitude', 'origin_longitude',
            'destination_address', 'destination_latitude', 'destination_longitude',
            'payment_method', 'passenger_notes'
        ]


class TripDetailSerializer(serializers.ModelSerializer):
    """
    Serializer detallado para un viaje
    """
    passenger = UserProfileSerializer(read_only=True)
    driver = AvailableDriverSerializer(read_only=True)
    duration_minutes = serializers.IntegerField(read_only=True)
    
    class Meta:
        model = Trip
        fields = [
            'id', 'trip_id', 'passenger', 'driver', 'origin_address',
            'origin_latitude', 'origin_longitude', 'destination_address',
            'destination_latitude', 'destination_longitude', 'distance_km',
            'estimated_duration_minutes', 'estimated_cost', 'final_cost',
            'status', 'payment_method', 'is_paid', 'passenger_notes',
            'driver_notes', 'requested_at', 'accepted_at', 'started_at',
            'completed_at', 'cancelled_at', 'duration_minutes'
        ]
        read_only_fields = [
            'id', 'trip_id', 'passenger', 'driver', 'distance_km',
            'estimated_duration_minutes', 'estimated_cost', 'final_cost',
            'requested_at', 'accepted_at', 'started_at', 'completed_at',
            'cancelled_at', 'duration_minutes'
        ]


class TripListSerializer(serializers.ModelSerializer):
    """
    Serializer simplificado para lista de viajes
    """
    passenger_name = serializers.CharField(source='passenger.get_full_name', read_only=True)
    driver_name = serializers.CharField(source='driver.user.get_full_name', read_only=True)
    
    class Meta:
        model = Trip
        fields = [
            'id', 'trip_id', 'passenger_name', 'driver_name',
            'origin_address', 'destination_address', 'status',
            'estimated_cost', 'final_cost', 'requested_at', 'completed_at'
        ]


class TripStatusUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer para actualizar el estado del viaje
    """
    class Meta:
        model = Trip
        fields = ['status', 'driver_notes']


class TripLocationSerializer(serializers.ModelSerializer):
    """
    Serializer para las ubicaciones del viaje en tiempo real
    """
    class Meta:
        model = TripLocation
        fields = ['id', 'trip', 'latitude', 'longitude', 'timestamp']
        read_only_fields = ['id', 'timestamp']


class TripCancellationSerializer(serializers.ModelSerializer):
    """
    Serializer para cancelaciones de viajes
    """
    cancelled_by_name = serializers.CharField(source='cancelled_by.get_full_name', read_only=True)
    
    class Meta:
        model = TripCancellation
        fields = [
            'id', 'trip', 'cancelled_by', 'cancelled_by_name',
            'reason', 'description', 'cancelled_at'
        ]
        read_only_fields = ['id', 'cancelled_by_name', 'cancelled_at']
