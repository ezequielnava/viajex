from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from users.models import User
from drivers.models import Driver
import uuid


class Trip(models.Model):
    """
    Modelo principal para los viajes
    """
    STATUS_CHOICES = [
        ('requested', 'Solicitado'),
        ('accepted', 'Aceptado'),
        ('driver_arrived', 'Conductor llegó'),
        ('in_progress', 'En progreso'),
        ('completed', 'Completado'),
        ('cancelled', 'Cancelado'),
    ]
    
    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Efectivo'),
        ('mobile_payment', 'Pago Móvil'),
    ]
    
    # Identificador único
    trip_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    
    # Relaciones
    passenger = models.ForeignKey(User, on_delete=models.CASCADE, related_name='passenger_trips')
    driver = models.ForeignKey(Driver, on_delete=models.SET_NULL, null=True, blank=True, related_name='driver_trips')
    
    # Ubicaciones
    origin_address = models.CharField(max_length=255)
    origin_latitude = models.DecimalField(max_digits=9, decimal_places=6)
    origin_longitude = models.DecimalField(max_digits=9, decimal_places=6)
    
    destination_address = models.CharField(max_length=255)
    destination_latitude = models.DecimalField(max_digits=9, decimal_places=6)
    destination_longitude = models.DecimalField(max_digits=9, decimal_places=6)
    
    # Información del viaje
    distance_km = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    estimated_duration_minutes = models.PositiveIntegerField(null=True, blank=True)
    estimated_cost = models.DecimalField(max_digits=8, decimal_places=2)
    final_cost = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    
    # Estado y pago
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='requested')
    payment_method = models.CharField(max_length=15, choices=PAYMENT_METHOD_CHOICES, default='cash')
    is_paid = models.BooleanField(default=False)
    
    # Notas adicionales
    passenger_notes = models.TextField(blank=True, help_text="Notas del pasajero")
    driver_notes = models.TextField(blank=True, help_text="Notas del conductor")
    
    # Timestamps
    requested_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Viaje {self.trip_id} - {self.passenger.username} ({self.status})"
    
    @property
    def duration_minutes(self):
        """Calcula la duración real del viaje en minutos"""
        if self.started_at and self.completed_at:
            duration = self.completed_at - self.started_at
            return int(duration.total_seconds() / 60)
        return None
    
    class Meta:
        db_table = 'trips'
        ordering = ['-requested_at']
        verbose_name = 'Viaje'
        verbose_name_plural = 'Viajes'


class TripLocation(models.Model):
    """
    Modelo para el seguimiento en tiempo real de la ubicación durante el viaje
    """
    trip = models.ForeignKey(Trip, on_delete=models.CASCADE, related_name='location_updates')
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'trip_locations'
        ordering = ['-timestamp']
        verbose_name = 'Ubicación de Viaje'
        verbose_name_plural = 'Ubicaciones de Viajes'
    
    def __str__(self):
        return f"Ubicación {self.trip.trip_id} - {self.timestamp}"


class TripCancellation(models.Model):
    """
    Modelo para registrar las cancelaciones de viajes
    """
    CANCELLATION_REASON_CHOICES = [
        ('passenger_request', 'Solicitud del pasajero'),
        ('driver_unavailable', 'Conductor no disponible'),
        ('weather_conditions', 'Condiciones climáticas'),
        ('vehicle_problem', 'Problema con el vehículo'),
        ('other', 'Otro motivo'),
    ]
    
    trip = models.OneToOneField(Trip, on_delete=models.CASCADE, related_name='cancellation')
    cancelled_by = models.ForeignKey(User, on_delete=models.CASCADE)
    reason = models.CharField(max_length=20, choices=CANCELLATION_REASON_CHOICES)
    description = models.TextField(blank=True)
    cancelled_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'trip_cancellations'
        verbose_name = 'Cancelación de Viaje'
        verbose_name_plural = 'Cancelaciones de Viajes'
    
    def __str__(self):
        return f"Cancelación {self.trip.trip_id} por {self.cancelled_by.username}"
