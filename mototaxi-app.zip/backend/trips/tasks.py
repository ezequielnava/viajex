from celery import shared_task
from django.utils import timezone
from datetime import timedelta
from .models import Trip
from .services import TripMatchingService, NotificationService


@shared_task
def auto_assign_drivers():
    """
    Tarea para asignar automáticamente conductores a viajes pendientes
    """
    # Buscar viajes solicitados hace más de 2 minutos sin conductor
    pending_trips = Trip.objects.filter(
        status='requested',
        driver__isnull=True,
        requested_at__lte=timezone.now() - timedelta(minutes=2)
    )
    
    assigned_count = 0
    for trip in pending_trips:
        driver = TripMatchingService.auto_assign_driver(trip)
        if driver:
            assigned_count += 1
            # Enviar notificación al conductor
            NotificationService.send_trip_request_notification(driver, trip)
    
    return f"Asignados {assigned_count} viajes automáticamente"


@shared_task
def cancel_expired_trips():
    """
    Cancelar viajes que han estado pendientes por mucho tiempo
    """
    # Cancelar viajes solicitados hace más de 15 minutos sin conductor
    expired_trips = Trip.objects.filter(
        status='requested',
        requested_at__lte=timezone.now() - timedelta(minutes=15)
    )
    
    cancelled_count = 0
    for trip in expired_trips:
        trip.status = 'cancelled'
        trip.cancelled_at = timezone.now()
        trip.save()
        cancelled_count += 1
        
        # Notificar al pasajero
        NotificationService.send_trip_cancelled_notification(trip.passenger, trip)
    
    return f"Cancelados {cancelled_count} viajes expirados"


@shared_task
def cleanup_old_locations():
    """
    Limpiar ubicaciones antiguas de viajes
    """
    from .models import TripLocation
    
    # Eliminar ubicaciones de más de 7 días
    old_date = timezone.now() - timedelta(days=7)
    deleted_count = TripLocation.objects.filter(
        timestamp__lt=old_date
    ).delete()[0]
    
    return f"Eliminadas {deleted_count} ubicaciones antiguas"
