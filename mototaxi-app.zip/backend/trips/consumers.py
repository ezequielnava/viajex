import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import AnonymousUser
from .models import Trip, TripLocation
from drivers.models import Driver


class TripConsumer(AsyncWebsocketConsumer):
    """
    Consumer para seguimiento en tiempo real de viajes
    """
    
    async def connect(self):
        self.trip_id = self.scope['url_route']['kwargs']['trip_id']
        self.trip_group_name = f'trip_{self.trip_id}'
        
        # Verificar que el usuario tenga acceso al viaje
        user = self.scope["user"]
        if isinstance(user, AnonymousUser):
            await self.close()
            return
        
        has_access = await self.check_trip_access(user, self.trip_id)
        if not has_access:
            await self.close()
            return
        
        # Unirse al grupo del viaje
        await self.channel_layer.group_add(
            self.trip_group_name,
            self.channel_name
        )
        
        await self.accept()
    
    async def disconnect(self, close_code):
        # Salir del grupo del viaje
        await self.channel_layer.group_discard(
            self.trip_group_name,
            self.channel_name
        )
    
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message_type = text_data_json.get('type')
        
        if message_type == 'location_update':
            # Actualizar ubicación del conductor
            await self.handle_location_update(text_data_json)
        elif message_type == 'status_update':
            # Actualizar estado del viaje
            await self.handle_status_update(text_data_json)
    
    async def handle_location_update(self, data):
        """Manejar actualización de ubicación"""
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        
        if latitude and longitude:
            # Guardar ubicación en la base de datos
            await self.save_trip_location(self.trip_id, latitude, longitude)
            
            # Enviar actualización a todos los miembros del grupo
            await self.channel_layer.group_send(
                self.trip_group_name,
                {
                    'type': 'location_message',
                    'latitude': latitude,
                    'longitude': longitude,
                    'timestamp': data.get('timestamp')
                }
            )
    
    async def handle_status_update(self, data):
        """Manejar actualización de estado del viaje"""
        status = data.get('status')
        
        if status:
            # Actualizar estado en la base de datos
            await self.update_trip_status(self.trip_id, status)
            
            # Enviar actualización a todos los miembros del grupo
            await self.channel_layer.group_send(
                self.trip_group_name,
                {
                    'type': 'status_message',
                    'status': status,
                    'timestamp': data.get('timestamp')
                }
            )
    
    async def location_message(self, event):
        """Enviar mensaje de ubicación al WebSocket"""
        await self.send(text_data=json.dumps({
            'type': 'location_update',
            'latitude': event['latitude'],
            'longitude': event['longitude'],
            'timestamp': event['timestamp']
        }))
    
    async def status_message(self, event):
        """Enviar mensaje de estado al WebSocket"""
        await self.send(text_data=json.dumps({
            'type': 'status_update',
            'status': event['status'],
            'timestamp': event['timestamp']
        }))
    
    @database_sync_to_async
    def check_trip_access(self, user, trip_id):
        """Verificar que el usuario tenga acceso al viaje"""
        try:
            trip = Trip.objects.get(trip_id=trip_id)
            return (trip.passenger == user or 
                   (hasattr(user, 'driver_profile') and trip.driver == user.driver_profile))
        except Trip.DoesNotExist:
            return False
    
    @database_sync_to_async
    def save_trip_location(self, trip_id, latitude, longitude):
        """Guardar ubicación del viaje"""
        try:
            trip = Trip.objects.get(trip_id=trip_id)
            TripLocation.objects.create(
                trip=trip,
                latitude=latitude,
                longitude=longitude
            )
        except Trip.DoesNotExist:
            pass
    
    @database_sync_to_async
    def update_trip_status(self, trip_id, status):
        """Actualizar estado del viaje"""
        try:
            trip = Trip.objects.get(trip_id=trip_id)
            trip.status = status
            trip.save()
        except Trip.DoesNotExist:
            pass


class DriverLocationConsumer(AsyncWebsocketConsumer):
    """
    Consumer para seguimiento de ubicación de conductores
    """
    
    async def connect(self):
        self.driver_id = self.scope['url_route']['kwargs']['driver_id']
        self.driver_group_name = f'driver_{self.driver_id}'
        
        # Verificar que el usuario sea el conductor
        user = self.scope["user"]
        if isinstance(user, AnonymousUser):
            await self.close()
            return
        
        is_driver = await self.check_driver_access(user, self.driver_id)
        if not is_driver:
            await self.close()
            return
        
        # Unirse al grupo del conductor
        await self.channel_layer.group_add(
            self.driver_group_name,
            self.channel_name
        )
        
        await self.accept()
    
    async def disconnect(self, close_code):
        # Salir del grupo del conductor
        await self.channel_layer.group_discard(
            self.driver_group_name,
            self.channel_name
        )
    
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message_type = text_data_json.get('type')
        
        if message_type == 'location_update':
            latitude = text_data_json.get('latitude')
            longitude = text_data_json.get('longitude')
            
            if latitude and longitude:
                # Actualizar ubicación del conductor
                await self.update_driver_location(self.driver_id, latitude, longitude)
    
    @database_sync_to_async
    def check_driver_access(self, user, driver_id):
        """Verificar que el usuario sea el conductor"""
        try:
            driver = Driver.objects.get(id=driver_id)
            return driver.user == user
        except Driver.DoesNotExist:
            return False
    
    @database_sync_to_async
    def update_driver_location(self, driver_id, latitude, longitude):
        """Actualizar ubicación del conductor"""
        try:
            driver = Driver.objects.get(id=driver_id)
            driver.user.current_latitude = latitude
            driver.user.current_longitude = longitude
            driver.user.save()
            driver.last_location_update = timezone.now()
            driver.save()
        except Driver.DoesNotExist:
            pass
