from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from .models import Trip


@receiver(post_save, sender=Trip)
def handle_trip_status_changes(sender, instance, **kwargs):
    """
    Manejar cambios de estado en los viajes
    """
    if instance.status == 'accepted' and not instance.accepted_at:
        instance.accepted_at = timezone.now()
        instance.save(update_fields=['accepted_at'])
    
    elif instance.status == 'in_progress' and not instance.started_at:
        instance.started_at = timezone.now()
        instance.save(update_fields=['started_at'])
    
    elif instance.status == 'completed' and not instance.completed_at:
        instance.completed_at = timezone.now()
        # Si no se ha establecido el costo final, usar el estimado
        if not instance.final_cost:
            instance.final_cost = instance.estimated_cost
        instance.save(update_fields=['completed_at', 'final_cost'])
        
        # Actualizar estadísticas del conductor
        if instance.driver:
            driver = instance.driver
            driver.total_trips += 1
            driver.total_earnings += instance.final_cost
            driver.save(update_fields=['total_trips', 'total_earnings'])
    
    elif instance.status == 'cancelled' and not instance.cancelled_at:
        instance.cancelled_at = timezone.now()
        instance.save(update_fields=['cancelled_at'])
        
        # Liberar conductor si estaba asignado
        if instance.driver:
            driver = instance.driver
            driver.status = 'online'
            driver.is_available = True
            driver.save(update_fields=['status', 'is_available'])
