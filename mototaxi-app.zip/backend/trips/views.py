from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone
from django.db.models import Q
from django.shortcuts import get_object_or_404
from .models import Trip, TripLocation, TripCancellation
from .serializers import (
    TripRequestSerializer, TripDetailSerializer, TripListSerializer,
    TripStatusUpdateSerializer, TripLocationSerializer, TripCancellationSerializer
)
from drivers.models import Driver
import math


class TripRequestView(APIView):
    """
    Vista para solicitar un nuevo viaje
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        # Verificar que el usuario no tenga un viaje activo
        active_trip = Trip.objects.filter(
            passenger=request.user,
            status__in=['requested', 'accepted', 'driver_arrived', 'in_progress']
        ).first()
        
        if active_trip:
            return Response({
                'error': 'Ya tienes un viaje activo',
                'active_trip': TripDetailSerializer(active_trip).data
            }, status=status.HTTP_400_BAD_REQUEST)
        
        serializer = TripRequestSerializer(data=request.data)
        if serializer.is_valid():
            # Calcular distancia y costo estimado
            origin_lat = float(serializer.validated_data['origin_latitude'])
            origin_lng = float(serializer.validated_data['origin_longitude'])
            dest_lat = float(serializer.validated_data['destination_latitude'])
            dest_lng = float(serializer.validated_data['destination_longitude'])
            
            # Cálculo básico de distancia (Haversine)
            distance_km = self.calculate_distance(origin_lat, origin_lng, dest_lat, dest_lng)
            
            # Cálculo de costo (tarifa base + por km)
            base_fare = 2.00  # Tarifa base en USD
            per_km_rate = 0.50  # Tarifa por km
            estimated_cost = base_fare + (distance_km * per_km_rate)
            
            # Tiempo estimado (asumiendo 30 km/h promedio)
            estimated_duration = int((distance_km / 30) * 60)  # en minutos
            
            trip = serializer.save(
                passenger=request.user,
                distance_km=round(distance_km, 2),
                estimated_cost=round(estimated_cost, 2),
                estimated_duration_minutes=estimated_duration
            )
            
            return Response({
                'message': 'Viaje solicitado exitosamente',
                'trip': TripDetailSerializer(trip).data
            }, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def calculate_distance(self, lat1, lon1, lat2, lon2):
        """Calcular distancia usando fórmula Haversine"""
        R = 6371  # Radio de la Tierra en km
        
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        
        a = (math.sin(dlat/2) * math.sin(dlat/2) +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon/2) * math.sin(dlon/2))
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        return distance


class CurrentTripView(APIView):
    """
    Vista para obtener el viaje actual del usuario
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        # Buscar viaje activo como pasajero
        trip = Trip.objects.filter(
            passenger=request.user,
            status__in=['requested', 'accepted', 'driver_arrived', 'in_progress']
        ).first()
        
        # Si no hay viaje como pasajero, buscar como conductor
        if not trip and hasattr(request.user, 'driver_profile'):
            trip = Trip.objects.filter(
                driver=request.user.driver_profile,
                status__in=['accepted', 'driver_arrived', 'in_progress']
            ).first()
        
        if trip:
            serializer = TripDetailSerializer(trip)
            return Response(serializer.data)
        
        return Response({
            'message': 'No hay viajes activos'
        }, status=status.HTTP_404_NOT_FOUND)


class TripAcceptView(APIView):
    """
    Vista para que un conductor acepte un viaje
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def put(self, request, pk):
        try:
            driver = request.user.driver_profile
        except:
            return Response({
                'error': 'Usuario no es conductor'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        trip = get_object_or_404(Trip, pk=pk, status='requested')
        
        # Verificar que el conductor esté disponible
        if not driver.is_available or driver.status != 'online':
            return Response({
                'error': 'Conductor no disponible'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Asignar conductor y cambiar estado
        trip.driver = driver
        trip.status = 'accepted'
        trip.accepted_at = timezone.now()
        trip.save()
        
        # Cambiar estado del conductor a ocupado
        driver.status = 'busy'
        driver.is_available = False
        driver.save()
        
        return Response({
            'message': 'Viaje aceptado exitosamente',
            'trip': TripDetailSerializer(trip).data
        })


class TripCompleteView(APIView):
    """
    Vista para completar un viaje
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def put(self, request, pk):
        try:
            driver = request.user.driver_profile
        except:
            return Response({
                'error': 'Usuario no es conductor'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        trip = get_object_or_404(Trip, pk=pk, driver=driver, status='in_progress')
        
        # Completar viaje
        trip.status = 'completed'
        trip.completed_at = timezone.now()
        trip.final_cost = trip.estimated_cost  # Por ahora usar costo estimado
        trip.save()
        
        # Actualizar estadísticas del conductor
        driver.total_trips += 1
        driver.total_earnings += trip.final_cost
        driver.status = 'online'
        driver.is_available = True
        driver.save()
        
        return Response({
            'message': 'Viaje completado exitosamente',
            'trip': TripDetailSerializer(trip).data
        })


class TripCancelView(APIView):
    """
    Vista para cancelar un viaje
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def put(self, request, pk):
        trip = get_object_or_404(Trip, pk=pk)
        
        # Verificar que el usuario puede cancelar el viaje
        can_cancel = (
            trip.passenger == request.user or
            (hasattr(request.user, 'driver_profile') and trip.driver == request.user.driver_profile)
        )
        
        if not can_cancel:
            return Response({
                'error': 'No tienes permisos para cancelar este viaje'
            }, status=status.HTTP_403_FORBIDDEN)
        
        if trip.status in ['completed', 'cancelled']:
            return Response({
                'error': 'El viaje ya está finalizado'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Cancelar viaje
        trip.status = 'cancelled'
        trip.cancelled_at = timezone.now()
        trip.save()
        
        # Crear registro de cancelación
        cancellation_data = request.data.copy()
        cancellation_data['trip'] = trip.id
        cancellation_serializer = TripCancellationSerializer(data=cancellation_data)
        
        if cancellation_serializer.is_valid():
            cancellation_serializer.save(cancelled_by=request.user)
        
        # Si había conductor asignado, liberarlo
        if trip.driver:
            trip.driver.status = 'online'
            trip.driver.is_available = True
            trip.driver.save()
        
        return Response({
            'message': 'Viaje cancelado exitosamente',
            'trip': TripDetailSerializer(trip).data
        })


class TripViewSet(viewsets.ModelViewSet):
    """
    ViewSet para operaciones CRUD de viajes
    """
    serializer_class = TripDetailSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        queryset = Trip.objects.none()
        
        # Viajes como pasajero
        passenger_trips = Trip.objects.filter(passenger=user)
        queryset = queryset.union(passenger_trips)
        
        # Viajes como conductor
        if hasattr(user, 'driver_profile'):
            driver_trips = Trip.objects.filter(driver=user.driver_profile)
            queryset = queryset.union(driver_trips)
        
        return queryset.order_by('-requested_at')
    
    def get_serializer_class(self):
        if self.action == 'list':
            return TripListSerializer
        return TripDetailSerializer
    
    @action(detail=True, methods=['put'])
    def update_status(self, request, pk=None):
        """Actualizar estado del viaje"""
        trip = self.get_object()
        serializer = TripStatusUpdateSerializer(trip, data=request.data, partial=True)
        
        if serializer.is_valid():
            # Validar transiciones de estado
            old_status = trip.status
            new_status = serializer.validated_data.get('status', old_status)
            
            if self.is_valid_status_transition(old_status, new_status):
                if new_status == 'driver_arrived':
                    # Conductor llegó al punto de origen
                    pass
                elif new_status == 'in_progress':
                    trip.started_at = timezone.now()
                
                serializer.save()
                return Response({
                    'message': 'Estado actualizado exitosamente',
                    'trip': TripDetailSerializer(trip).data
                })
            else:
                return Response({
                    'error': f'Transición de estado inválida: {old_status} -> {new_status}'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def is_valid_status_transition(self, old_status, new_status):
        """Validar transiciones de estado válidas"""
        valid_transitions = {
            'requested': ['accepted', 'cancelled'],
            'accepted': ['driver_arrived', 'cancelled'],
            'driver_arrived': ['in_progress', 'cancelled'],
            'in_progress': ['completed', 'cancelled'],
            'completed': [],
            'cancelled': []
        }
        
        return new_status in valid_transitions.get(old_status, [])


class TripLocationViewSet(viewsets.ModelViewSet):
    """
    ViewSet para ubicaciones de viajes en tiempo real
    """
    queryset = TripLocation.objects.all()
    serializer_class = TripLocationSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        trip_id = self.request.query_params.get('trip_id')
        if trip_id:
            return TripLocation.objects.filter(trip_id=trip_id).order_by('-timestamp')
        return TripLocation.objects.none()
    
    def perform_create(self, serializer):
        # Solo conductores pueden crear ubicaciones
        trip = serializer.validated_data['trip']
        if hasattr(self.request.user, 'driver_profile') and trip.driver == self.request.user.driver_profile:
            serializer.save()
        else:
            raise permissions.PermissionDenied("Solo el conductor puede actualizar la ubicación")
