from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'', views.TripViewSet, basename='trip')
router.register(r'locations', views.TripLocationViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('request/', views.TripRequestView.as_view(), name='trip-request'),
    path('current/', views.CurrentTripView.as_view(), name='current-trip'),
    path('<int:pk>/accept/', views.TripAcceptView.as_view(), name='trip-accept'),
    path('<int:pk>/complete/', views.TripCompleteView.as_view(), name='trip-complete'),
    path('<int:pk>/cancel/', views.TripCancelView.as_view(), name='trip-cancel'),
]
