import math
import requests
from decimal import Decimal
from django.conf import settings
from django.utils import timezone
from django.db.models import Q, F
from .models import Trip, TripLocation
from drivers.models import Driver
from users.models import User


class TripMatchingService:
    """
    Servicio para asignar conductores a viajes
    """
    
    @staticmethod
    def find_nearest_drivers(origin_lat, origin_lng, radius_km=5, limit=10):
        """
        Encontrar conductores disponibles más cercanos
        """
        # Convertir radio a grados aproximados (1 grado ≈ 111 km)
        radius_deg = radius_km / 111.0
        
        # Buscar conductores disponibles en el área
        available_drivers = Driver.objects.filter(
            status='online',
            is_available=True,
            is_verified=True,
            user__current_latitude__isnull=False,
            user__current_longitude__isnull=False,
            user__current_latitude__range=(origin_lat - radius_deg, origin_lat + radius_deg),
            user__current_longitude__range=(origin_lng - radius_deg, origin_lng + radius_deg)
        ).select_related('user')
        
        # Calcular distancias exactas y ordenar
        drivers_with_distance = []
        for driver in available_drivers:
            distance = TripMatchingService.calculate_distance(
                origin_lat, origin_lng,
                float(driver.user.current_latitude),
                float(driver.user.current_longitude)
            )
            if distance <= radius_km:
                drivers_with_distance.append((driver, distance))
        
        # Ordenar por distancia y rating
        drivers_with_distance.sort(key=lambda x: (x[1], -x[0].user.average_rating))
        
        return [driver for driver, distance in drivers_with_distance[:limit]]
    
    @staticmethod
    def calculate_distance(lat1, lon1, lat2, lon2):
        """
        Calcular distancia entre dos puntos usando fórmula Haversine
        """
        R = 6371  # Radio de la Tierra en km
        
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        
        a = (math.sin(dlat/2) * math.sin(dlat/2) +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon/2) * math.sin(dlon/2))
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        return distance
    
    @staticmethod
    def auto_assign_driver(trip):
        """
        Asignar automáticamente el conductor más cercano a un viaje
        """
        drivers = TripMatchingService.find_nearest_drivers(
            float(trip.origin_latitude),
            float(trip.origin_longitude),
            radius_km=10,
            limit=5
        )
        
        if drivers:
            # Asignar el primer conductor (más cercano y mejor calificado)
            best_driver = drivers[0]
            trip.driver = best_driver
            trip.status = 'accepted'
            trip.accepted_at = timezone.now()
            trip.save()
            
            # Actualizar estado del conductor
            best_driver.status = 'busy'
            best_driver.is_available = False
            best_driver.save()
            
            return best_driver
        
        return None


class FareCalculationService:
    """
    Servicio para cálculo de tarifas
    """
    
    # Configuración de tarifas
    BASE_FARE = Decimal('2.00')  # Tarifa base en USD
    PER_KM_RATE = Decimal('0.50')  # Tarifa por kilómetro
    PER_MINUTE_RATE = Decimal('0.10')  # Tarifa por minuto
    MINIMUM_FARE = Decimal('1.50')  # Tarifa mínima
    SURGE_MULTIPLIER = Decimal('1.0')  # Multiplicador por demanda alta
    
    @staticmethod
    def calculate_fare(distance_km, duration_minutes=None, surge_multiplier=None):
        """
        Calcular tarifa basada en distancia y tiempo
        """
        if surge_multiplier is None:
            surge_multiplier = FareCalculationService.SURGE_MULTIPLIER
        
        # Cálculo base
        distance_cost = Decimal(str(distance_km)) * FareCalculationService.PER_KM_RATE
        time_cost = Decimal('0')
        
        if duration_minutes:
            time_cost = Decimal(str(duration_minutes)) * FareCalculationService.PER_MINUTE_RATE
        
        total_fare = (FareCalculationService.BASE_FARE + distance_cost + time_cost) * surge_multiplier
        
        # Aplicar tarifa mínima
        total_fare = max(total_fare, FareCalculationService.MINIMUM_FARE)
        
        return round(total_fare, 2)
    
    @staticmethod
    def calculate_surge_multiplier(origin_lat, origin_lng, radius_km=3):
        """
        Calcular multiplicador de demanda basado en viajes activos en el área
        """
        # Contar viajes activos en el área
        active_trips = Trip.objects.filter(
            status__in=['requested', 'accepted', 'in_progress'],
            origin_latitude__range=(origin_lat - radius_km/111, origin_lat + radius_km/111),
            origin_longitude__range=(origin_lng - radius_km/111, origin_lng + radius_km/111)
        ).count()
        
        # Contar conductores disponibles en el área
        available_drivers = Driver.objects.filter(
            status='online',
            is_available=True,
            user__current_latitude__range=(origin_lat - radius_km/111, origin_lat + radius_km/111),
            user__current_longitude__range=(origin_lng - radius_km/111, origin_lng + radius_km/111)
        ).count()
        
        # Calcular multiplicador basado en oferta y demanda
        if available_drivers == 0:
            return Decimal('2.0')  # Alta demanda, sin conductores
        
        demand_ratio = active_trips / max(available_drivers, 1)
        
        if demand_ratio > 2:
            return Decimal('1.8')
        elif demand_ratio > 1.5:
            return Decimal('1.5')
        elif demand_ratio > 1:
            return Decimal('1.2')
        else:
            return Decimal('1.0')


class RouteService:
    """
    Servicio para cálculo de rutas usando Google Maps API
    """
    
    @staticmethod
    def get_route_info(origin_lat, origin_lng, dest_lat, dest_lng):
        """
        Obtener información de ruta desde Google Maps API
        """
        if not settings.GOOGLE_MAPS_API_KEY:
            # Fallback a cálculo básico si no hay API key
            distance = TripMatchingService.calculate_distance(
                origin_lat, origin_lng, dest_lat, dest_lng
            )
            duration = int((distance / 30) * 60)  # Asumiendo 30 km/h
            return {
                'distance_km': round(distance, 2),
                'duration_minutes': duration,
                'polyline': None
            }
        
        try:
            url = 'https://maps.googleapis.com/maps/api/directions/json'
            params = {
                'origin': f'{origin_lat},{origin_lng}',
                'destination': f'{dest_lat},{dest_lng}',
                'mode': 'driving',
                'key': settings.GOOGLE_MAPS_API_KEY
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            if data['status'] == 'OK' and data['routes']:
                route = data['routes'][0]['legs'][0]
                
                return {
                    'distance_km': round(route['distance']['value'] / 1000, 2),
                    'duration_minutes': round(route['duration']['value'] / 60),
                    'polyline': data['routes'][0]['overview_polyline']['points']
                }
            
        except Exception as e:
            print(f"Error obteniendo ruta: {e}")
        
        # Fallback a cálculo básico
        distance = TripMatchingService.calculate_distance(
            origin_lat, origin_lng, dest_lat, dest_lng
        )
        duration = int((distance / 30) * 60)
        
        return {
            'distance_km': round(distance, 2),
            'duration_minutes': duration,
            'polyline': None
        }


class TripService:
    """
    Servicio principal para gestión de viajes
    """
    
    @staticmethod
    def create_trip_request(passenger, trip_data):
        """
        Crear solicitud de viaje con cálculos automáticos
        """
        origin_lat = float(trip_data['origin_latitude'])
        origin_lng = float(trip_data['origin_longitude'])
        dest_lat = float(trip_data['destination_latitude'])
        dest_lng = float(trip_data['destination_longitude'])
        
        # Obtener información de ruta
        route_info = RouteService.get_route_info(origin_lat, origin_lng, dest_lat, dest_lng)
        
        # Calcular multiplicador de demanda
        surge_multiplier = FareCalculationService.calculate_surge_multiplier(origin_lat, origin_lng)
        
        # Calcular tarifa
        estimated_cost = FareCalculationService.calculate_fare(
            route_info['distance_km'],
            route_info['duration_minutes'],
            surge_multiplier
        )
        
        # Crear viaje
        trip = Trip.objects.create(
            passenger=passenger,
            origin_address=trip_data['origin_address'],
            origin_latitude=trip_data['origin_latitude'],
            origin_longitude=trip_data['origin_longitude'],
            destination_address=trip_data['destination_address'],
            destination_latitude=trip_data['destination_latitude'],
            destination_longitude=trip_data['destination_longitude'],
            distance_km=route_info['distance_km'],
            estimated_duration_minutes=route_info['duration_minutes'],
            estimated_cost=estimated_cost,
            payment_method=trip_data.get('payment_method', 'cash'),
            passenger_notes=trip_data.get('passenger_notes', '')
        )
        
        return trip
    
    @staticmethod
    def update_trip_location(trip, latitude, longitude):
        """
        Actualizar ubicación del viaje en tiempo real
        """
        TripLocation.objects.create(
            trip=trip,
            latitude=latitude,
            longitude=longitude
        )
        
        # Mantener solo las últimas 50 ubicaciones por viaje
        locations = TripLocation.objects.filter(trip=trip).order_by('-timestamp')
        if locations.count() > 50:
            old_locations = locations[50:]
            TripLocation.objects.filter(
                id__in=[loc.id for loc in old_locations]
            ).delete()
    
    @staticmethod
    def complete_trip(trip, final_cost=None):
        """
        Completar un viaje y actualizar estadísticas
        """
        if final_cost is None:
            final_cost = trip.estimated_cost
        
        trip.status = 'completed'
        trip.completed_at = timezone.now()
        trip.final_cost = final_cost
        trip.save()
        
        # Actualizar estadísticas del conductor
        if trip.driver:
            driver = trip.driver
            driver.total_trips = F('total_trips') + 1
            driver.total_earnings = F('total_earnings') + final_cost
            driver.status = 'online'
            driver.is_available = True
            driver.save()
            
            # Refrescar desde la base de datos
            driver.refresh_from_db()
        
        return trip


class PaymentService:
    """
    Servicio para gestión de pagos
    """
    
    @staticmethod
    def process_cash_payment(trip):
        """
        Procesar pago en efectivo
        """
        trip.is_paid = True
        trip.save()
        return {'status': 'success', 'method': 'cash'}
    
    @staticmethod
    def process_mobile_payment(trip, payment_data):
        """
        Procesar pago móvil (simulado)
        """
        # Aquí se integraría con el sistema de pago móvil real
        # Por ahora, simulamos el proceso
        
        reference_number = payment_data.get('reference_number')
        phone_number = payment_data.get('phone_number')
        
        if reference_number and phone_number:
            # Simular validación exitosa
            trip.is_paid = True
            trip.save()
            
            return {
                'status': 'success',
                'method': 'mobile_payment',
                'reference': reference_number
            }
        
        return {
            'status': 'error',
            'message': 'Datos de pago móvil inválidos'
        }
    
    @staticmethod
    def validate_mobile_payment(reference_number, phone_number, amount):
        """
        Validar pago móvil con el banco (simulado)
        """
        # Aquí se haría la consulta real al sistema bancario
        # Por ahora, simulamos una validación exitosa
        
        if len(reference_number) >= 6 and len(phone_number) >= 10:
            return {
                'valid': True,
                'amount': amount,
                'timestamp': timezone.now()
            }
        
        return {'valid': False}


class DriverService:
    """
    Servicio para gestión de conductores
    """
    
    @staticmethod
    def update_driver_location(driver, latitude, longitude):
        """
        Actualizar ubicación del conductor
        """
        driver.user.current_latitude = latitude
        driver.user.current_longitude = longitude
        driver.user.save()
        
        driver.last_location_update = timezone.now()
        driver.save()
    
    @staticmethod
    def set_driver_availability(driver, is_available):
        """
        Cambiar disponibilidad del conductor
        """
        if is_available:
            driver.status = 'online'
            driver.is_available = True
        else:
            driver.status = 'offline'
            driver.is_available = False
        
        driver.save()
    
    @staticmethod
    def get_driver_earnings(driver, start_date=None, end_date=None):
        """
        Obtener ganancias del conductor en un período
        """
        trips = Trip.objects.filter(
            driver=driver,
            status='completed'
        )
        
        if start_date:
            trips = trips.filter(completed_at__gte=start_date)
        if end_date:
            trips = trips.filter(completed_at__lte=end_date)
        
        total_earnings = sum(trip.final_cost for trip in trips if trip.final_cost)
        total_trips = trips.count()
        
        return {
            'total_earnings': total_earnings,
            'total_trips': total_trips,
            'average_per_trip': total_earnings / max(total_trips, 1)
        }
