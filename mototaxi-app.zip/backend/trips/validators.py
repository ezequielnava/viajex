from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import timedelta
from .models import Trip


class TripValidator:
    """
    Validadores para viajes
    """
    
    @staticmethod
    def validate_trip_request(passenger, trip_data):
        """
        Validar solicitud de viaje
        """
        errors = []
        
        # Verificar que el usuario no tenga un viaje activo
        active_trip = Trip.objects.filter(
            passenger=passenger,
            status__in=['requested', 'accepted', 'driver_arrived', 'in_progress']
        ).first()
        
        if active_trip:
            errors.append("Ya tienes un viaje activo")
        
        # Validar coordenadas
        try:
            origin_lat = float(trip_data['origin_latitude'])
            origin_lng = float(trip_data['origin_longitude'])
            dest_lat = float(trip_data['destination_latitude'])
            dest_lng = float(trip_data['destination_longitude'])
            
            # Validar rangos de coordenadas (Venezuela aproximadamente)
            if not (-15 <= origin_lat <= 15 and -75 <= origin_lng <= -55):
                errors.append("Coordenadas de origen fuera del área de servicio")
            
            if not (-15 <= dest_lat <= 15 and -75 <= dest_lng <= -55):
                errors.append("Coordenadas de destino fuera del área de servicio")
            
        except (ValueError, KeyError):
            errors.append("Coordenadas inválidas")
        
        # Validar distancia mínima (al menos 100 metros)
        if not errors:
            from .services import TripMatchingService
            distance = TripMatchingService.calculate_distance(
                origin_lat, origin_lng, dest_lat, dest_lng
            )
            if distance < 0.1:  # Menos de 100 metros
                errors.append("La distancia mínima del viaje es 100 metros")
        
        # Validar método de pago
        valid_payment_methods = ['cash', 'mobile_payment']
        if trip_data.get('payment_method') not in valid_payment_methods:
            errors.append("Método de pago inválido")
        
        if errors:
            raise ValidationError(errors)
        
        return True
    
    @staticmethod
    def validate_driver_acceptance(driver, trip):
        """
        Validar que un conductor puede aceptar un viaje
        """
        errors = []
        
        # Verificar que el conductor esté disponible
        if not driver.is_available or driver.status != 'online':
            errors.append("Conductor no disponible")
        
        # Verificar que el conductor esté verificado
        if not driver.is_verified:
            errors.append("Conductor no verificado")
        
        # Verificar que el viaje esté en estado correcto
        if trip.status != 'requested':
            errors.append("El viaje ya no está disponible")
        
        # Verificar que el conductor no tenga otro viaje activo
        active_trip = Trip.objects.filter(
            driver=driver,
            status__in=['accepted', 'driver_arrived', 'in_progress']
        ).first()
        
        if active_trip:
            errors.append("El conductor ya tiene un viaje activo")
        
        if errors:
            raise ValidationError(errors)
        
        return True
    
    @staticmethod
    def validate_status_transition(trip, new_status):
        """
        Validar transición de estado del viaje
        """
        valid_transitions = {
            'requested': ['accepted', 'cancelled'],
            'accepted': ['driver_arrived', 'cancelled'],
            'driver_arrived': ['in_progress', 'cancelled'],
            'in_progress': ['completed', 'cancelled'],
            'completed': [],
            'cancelled': []
        }
        
        current_status = trip.status
        valid_next_states = valid_transitions.get(current_status, [])
        
        if new_status not in valid_next_states:
            raise ValidationError(
                f"Transición de estado inválida: {current_status} -> {new_status}"
            )
        
        return True
