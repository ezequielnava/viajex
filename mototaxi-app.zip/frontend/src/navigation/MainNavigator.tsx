"use client"

import type React from "react"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import Icon from "react-native-vector-icons/MaterialIcons"

import { useAuth } from "../context/AuthContext"
import { colors } from "../styles/colors"

import HomeScreen from "../screens/main/HomeScreen"
import TripsScreen from "../screens/main/TripsScreen"
import ProfileScreen from "../screens/main/ProfileScreen"
import DriverHomeScreen from "../screens/driver/DriverHomeScreen"
import DriverTripsScreen from "../screens/driver/DriverTripsScreen"
import DriverEarningsScreen from "../screens/driver/DriverEarningsScreen"

export type MainTabParamList = {
  Home: undefined
  Trips: undefined
  Profile: undefined
  DriverHome: undefined
  DriverTrips: undefined
  DriverEarnings: undefined
}

const Tab = createBottomTabNavigator<MainTabParamList>()

const MainNavigator: React.FC = () => {
  const { user } = useAuth()
  const isDriver = user?.user_type === "driver"

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: string

          switch (route.name) {
            case "Home":
            case "DriverHome":
              iconName = "home"
              break
            case "Trips":
            case "DriverTrips":
              iconName = "directions-car"
              break
            case "DriverEarnings":
              iconName = "attach-money"
              break
            case "Profile":
              iconName = "person"
              break
            default:
              iconName = "help"
          }

          return <Icon name={iconName} size={size} color={color} />
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.gray500,
        tabBarStyle: {
          backgroundColor: colors.background,
          borderTopColor: colors.gray200,
        },
        headerShown: false,
      })}
    >
      {isDriver ? (
        <>
          <Tab.Screen name="DriverHome" component={DriverHomeScreen} options={{ title: "Inicio" }} />
          <Tab.Screen name="DriverTrips" component={DriverTripsScreen} options={{ title: "Viajes" }} />
          <Tab.Screen name="DriverEarnings" component={DriverEarningsScreen} options={{ title: "Ganancias" }} />
          <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: "Perfil" }} />
        </>
      ) : (
        <>
          <Tab.Screen name="Home" component={HomeScreen} options={{ title: "Inicio" }} />
          <Tab.Screen name="Trips" component={TripsScreen} options={{ title: "Viajes" }} />
          <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: "Perfil" }} />
        </>
      )}
    </Tab.Navigator>
  )
}

export default MainNavigator
