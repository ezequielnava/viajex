import type React from "react"
import { StatusBar } from "react-native"
import { NavigationContainer } from "@react-navigation/native"
import { GestureHandlerRootView } from "react-native-gesture-handler"
import { SafeAreaProvider } from "react-native-safe-area-context"
import Toast from "react-native-toast-message"

import { AuthProvider } from "./context/AuthContext"
import { TripProvider } from "./context/TripContext"
import AppNavigator from "./navigation/AppNavigator"
import { colors } from "./styles/colors"

const App: React.FC = () => {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <NavigationContainer>
          <AuthProvider>
            <TripProvider>
              <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
              <AppNavigator />
              <Toast />
            </TripProvider>
          </AuthProvider>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  )
}

export default App
