import axios, { type AxiosInstance, type AxiosRequestConfig } from "axios"
import AsyncStorage from "@react-native-async-storage/async-storage"
import Config from "react-native-config"

class APIClient {
  private client: AxiosInstance

  constructor() {
    this.client = axios.create({
      baseURL: Config.API_BASE_URL || "http://localhost:8000/api",
      timeout: 10000,
      headers: {
        "Content-Type": "application/json",
      },
    })

    this.setupInterceptors()
  }

  private setupInterceptors() {
    // Request interceptor para agregar token de autenticación
    this.client.interceptors.request.use(
      async (config) => {
        const tokens = await AsyncStorage.getItem("auth_tokens")
        if (tokens) {
          const { access } = JSON.parse(tokens)
          config.headers.Authorization = `Bearer ${access}`
        }
        return config
      },
      (error) => {
        return Promise.reject(error)
      },
    )

    // Response interceptor para manejar errores de autenticación
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config

        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true

          try {
            const tokens = await AsyncStorage.getItem("auth_tokens")
            if (tokens) {
              const { refresh } = JSON.parse(tokens)
              const response = await axios.post(`${Config.API_BASE_URL}/auth/token/refresh/`, { refresh })

              const newTokens = {
                access: response.data.access,
                refresh: refresh,
              }

              await AsyncStorage.setItem("auth_tokens", JSON.stringify(newTokens))
              originalRequest.headers.Authorization = `Bearer ${response.data.access}`

              return this.client(originalRequest)
            }
          } catch (refreshError) {
            // Token refresh falló, redirigir a login
            await AsyncStorage.removeItem("auth_tokens")
            await AsyncStorage.removeItem("user")
            // Aquí podrías emitir un evento para redirigir al login
          }
        }

        return Promise.reject(error)
      },
    )
  }

  async get<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.get(url, config)
    return response.data
  }

  async post<T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.post(url, data, config)
    return response.data
  }

  async put<T>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.put(url, data, config)
    return response.data
  }

  async delete<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await this.client.delete(url, config)
    return response.data
  }
}

export const apiClient = new APIClient()
