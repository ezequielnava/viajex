import { apiClient } from "./client"
import type { User, AuthTokens, LoginCredentials, RegisterData } from "../types"

interface LoginResponse {
  message: string
  user: User
  tokens: AuthTokens
}

interface RegisterResponse {
  message: string
  user: User
  tokens: AuthTokens
}

export const authAPI = {
  login: async (credentials: LoginCredentials): Promise<LoginResponse> => {
    return apiClient.post<LoginResponse>("/auth/login/", credentials)
  },

  register: async (data: RegisterData): Promise<RegisterResponse> => {
    return apiClient.post<RegisterResponse>("/auth/register/", data)
  },

  getProfile: async (): Promise<User> => {
    return apiClient.get<User>("/auth/profile/")
  },

  updateProfile: async (data: Partial<User>): Promise<{ message: string; user: User }> => {
    return apiClient.put<{ message: string; user: User }>("/auth/profile/", data)
  },

  updateLocation: async (latitude: number, longitude: number): Promise<{ message: string }> => {
    return apiClient.put<{ message: string }>("/auth/location/", {
      current_latitude: latitude,
      current_longitude: longitude,
    })
  },

  refreshToken: async (refreshToken: string): Promise<{ access: string }> => {
    return apiClient.post<{ access: string }>("/auth/token/refresh/", {
      refresh: refreshToken,
    })
  },
}
