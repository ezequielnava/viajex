import { apiClient } from "./client"
import type { Driver } from "../types"

interface AvailableDriversResponse {
  drivers: Driver[]
  count: number
}

export const driverAPI = {
  getAvailableDrivers: async (latitude: number, longitude: number, radius = 5): Promise<Driver[]> => {
    const response = await apiClient.get<AvailableDriversResponse>(
      `/drivers/available/?latitude=${latitude}&longitude=${longitude}&radius=${radius}`,
    )
    return response.drivers
  },

  updateDriverStatus: async (status: string, isAvailable: boolean): Promise<{ message: string }> => {
    return apiClient.put<{ message: string }>("/drivers/status/", {
      status,
      is_available: isAvailable,
    })
  },

  getDriverProfile: async (): Promise<Driver> => {
    return apiClient.get<Driver>("/drivers/me/")
  },

  getDriverEarnings: async (): Promise<{
    total_earnings: number
    total_trips: number
    average_per_trip: number
  }> => {
    return apiClient.get("/drivers/me/earnings/")
  },
}
