import { apiClient } from "./client"
import type { Trip, TripRequest } from "../types"

interface TripResponse {
  message: string
  trip: Trip
}

export const tripAPI = {
  requestTrip: async (tripData: TripRequest): Promise<Trip> => {
    const response = await apiClient.post<TripResponse>("/trips/request/", tripData)
    return response.trip
  },

  getCurrentTrip: async (): Promise<Trip | null> => {
    try {
      return await apiClient.get<Trip>("/trips/current/")
    } catch (error: any) {
      if (error.response?.status === 404) {
        return null
      }
      throw error
    }
  },

  getTripHistory: async (): Promise<Trip[]> => {
    return apiClient.get<Trip[]>("/trips/")
  },

  acceptTrip: async (tripId: number): Promise<Trip> => {
    const response = await apiClient.put<TripResponse>(`/trips/${tripId}/accept/`)
    return response.trip
  },

  completeTrip: async (tripId: number): Promise<Trip> => {
    const response = await apiClient.put<TripResponse>(`/trips/${tripId}/complete/`)
    return response.trip
  },

  cancelTrip: async (tripId: number, reason: string): Promise<void> => {
    await apiClient.put(`/trips/${tripId}/cancel/`, {
      reason: "passenger_request",
      description: reason,
    })
  },

  updateTripStatus: async (tripId: number, status: string): Promise<Trip> => {
    const response = await apiClient.put<TripResponse>(`/trips/${tripId}/update_status/`, {
      status,
    })
    return response.trip
  },

  getTripDetails: async (tripId: number): Promise<Trip> => {
    return apiClient.get<Trip>(`/trips/${tripId}/`)
  },
}
