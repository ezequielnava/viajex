"use client"

import type React from "react"
import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from "react-native"
import Icon from "react-native-vector-icons/MaterialIcons"
import { useTrip } from "../../context/TripContext"
import type { Trip } from "../../types"
import { colors } from "../../styles/colors"
import { typography } from "../../styles/typography"
import { spacing } from "../../styles/spacing"

const TripsScreen: React.FC = () => {
  const { tripHistory, loadTripHistory, isLoading } = useTrip()
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    loadTripHistory()
  }, [])

  const onRefresh = async () => {
    setRefreshing(true)
    await loadTripHistory()
    setRefreshing(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return colors.success
      case "cancelled":
        return colors.error
      case "in_progress":
        return colors.warning
      default:
        return colors.info
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "requested":
        return "Solicitado"
      case "accepted":
        return "Aceptado"
      case "driver_arrived":
        return "Conductor llegó"
      case "in_progress":
        return "En progreso"
      case "completed":
        return "Completado"
      case "cancelled":
        return "Cancelado"
      default:
        return status
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const renderTripItem = ({ item }: { item: Trip }) => (
    <TouchableOpacity style={styles.tripItem}>
      <View style={styles.tripHeader}>
        <View style={styles.tripInfo}>
          <Text style={styles.tripDate}>{formatDate(item.requested_at)}</Text>
          <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
            <Text style={styles.statusText}>{getStatusText(item.status)}</Text>
          </View>
        </View>
        <Text style={styles.tripCost}>
          ${item.final_cost ? item.final_cost.toFixed(2) : item.estimated_cost.toFixed(2)}
        </Text>
      </View>

      <View style={styles.tripRoute}>
        <View style={styles.routePoint}>
          <Icon name="radio-button-checked" size={16} color={colors.success} />
          <Text style={styles.routeText} numberOfLines={1}>
            {item.origin_address}
          </Text>
        </View>

        <View style={styles.routeLine} />

        <View style={styles.routePoint}>
          <Icon name="place" size={16} color={colors.error} />
          <Text style={styles.routeText} numberOfLines={1}>
            {item.destination_address}
          </Text>
        </View>
      </View>

      {item.driver && (
        <View style={styles.driverInfo}>
          <Icon name="person" size={16} color={colors.gray500} />
          <Text style={styles.driverText}>
            {item.driver.user.first_name} {item.driver.user.last_name} - {item.driver.license_plate}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  )

  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <Icon name="directions-car" size={64} color={colors.gray400} />
      <Text style={styles.emptyStateTitle}>No hay viajes aún</Text>
      <Text style={styles.emptyStateText}>Tus viajes aparecerán aquí una vez que solicites uno</Text>
    </View>
  )

  if (isLoading && tripHistory.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Cargando viajes...</Text>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Mis Viajes</Text>
        <Text style={styles.subtitle}>Historial de tus viajes realizados</Text>
      </View>

      <FlatList
        data={tripHistory}
        renderItem={renderTripItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} />}
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray200,
  },
  title: {
    fontSize: typography.sizes["2xl"],
    fontWeight: typography.weights.bold,
    color: colors.text,
  },
  subtitle: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  listContainer: {
    padding: spacing.lg,
  },
  tripItem: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: spacing.md,
    elevation: 2,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  tripHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.md,
  },
  tripInfo: {
    flex: 1,
  },
  tripDate: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  statusBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },
  statusText: {
    fontSize: typography.sizes.xs,
    color: colors.textLight,
    fontWeight: typography.weights.semibold,
  },
  tripCost: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },
  tripRoute: {
    marginBottom: spacing.md,
  },
  routePoint: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.xs,
  },
  routeText: {
    flex: 1,
    fontSize: typography.sizes.base,
    color: colors.text,
    marginLeft: spacing.sm,
  },
  routeLine: {
    width: 2,
    height: 20,
    backgroundColor: colors.gray300,
    marginLeft: 7,
    marginVertical: spacing.xs,
  },
  driverInfo: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.gray200,
  },
  driverText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginLeft: spacing.sm,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: spacing.xl,
  },
  emptyStateTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptyStateText: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    textAlign: "center",
    lineHeight: 24,
  },
})

export default TripsScreen
