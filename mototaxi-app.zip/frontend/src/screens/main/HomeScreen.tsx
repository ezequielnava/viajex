"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Alert, Modal } from "react-native"
import Icon from "react-native-vector-icons/MaterialIcons"
import { useAuth } from "../../context/AuthContext"
import { useTrip } from "../../context/TripContext"
import { locationService } from "../../services/LocationService"
import { geocodingService } from "../../services/GeocodingService"
import CustomMapView from "../../components/MapView"
import AddressSearchInput from "../../components/AddressSearchInput"
import type { Location, TripRequest } from "../../types"
import { colors } from "../../styles/colors"
import { typography } from "../../styles/typography"
import { spacing } from "../../styles/spacing"

const HomeScreen: React.FC = () => {
  const { user } = useAuth()
  const { currentTrip, requestTrip, isLoading } = useTrip()

  const [userLocation, setUserLocation] = useState<Location | null>(null)
  const [originAddress, setOriginAddress] = useState("")
  const [destinationAddress, setDestinationAddress] = useState("")
  const [originLocation, setOriginLocation] = useState<Location | null>(null)
  const [destinationLocation, setDestinationLocation] = useState<Location | null>(null)
  const [showTripModal, setShowTripModal] = useState(false)
  const [estimatedCost, setEstimatedCost] = useState<number>(0)
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "mobile_payment">("cash")

  useEffect(() => {
    getCurrentLocation()
  }, [])

  useEffect(() => {
    if (originLocation && destinationLocation) {
      calculateEstimatedCost()
    }
  }, [originLocation, destinationLocation])

  const getCurrentLocation = async () => {
    try {
      const location = await locationService.requestLocationWithPermission()
      setUserLocation(location)

      // Obtener dirección actual
      const address = await geocodingService.getAddressFromCoordinates(location.latitude, location.longitude)
      setOriginAddress(address)
      setOriginLocation(location)
    } catch (error: any) {
      Alert.alert("Error de ubicación", error.message)
    }
  }

  const calculateEstimatedCost = () => {
    if (!originLocation || !destinationLocation) return

    const distance = locationService.calculateDistance(
      originLocation.latitude,
      originLocation.longitude,
      destinationLocation.latitude,
      destinationLocation.longitude,
    )

    // Cálculo básico de tarifa
    const baseFare = 2.0
    const perKmRate = 0.5
    const cost = baseFare + distance * perKmRate
    setEstimatedCost(Math.max(cost, 1.5)) // Mínimo $1.50
  }

  const handleOriginSelect = (address: string, location: Location) => {
    setOriginAddress(address)
    setOriginLocation(location)
  }

  const handleDestinationSelect = (address: string, location: Location) => {
    setDestinationAddress(address)
    setDestinationLocation(location)
    setShowTripModal(true)
  }

  const handleRequestTrip = async () => {
    if (!originLocation || !destinationLocation) {
      Alert.alert("Error", "Por favor selecciona origen y destino")
      return
    }

    try {
      const tripData: TripRequest = {
        origin_address: originAddress,
        origin_latitude: originLocation.latitude,
        origin_longitude: originLocation.longitude,
        destination_address: destinationAddress,
        destination_latitude: destinationLocation.latitude,
        destination_longitude: destinationLocation.longitude,
        payment_method: paymentMethod,
        passenger_notes: "",
      }

      await requestTrip(tripData)
      setShowTripModal(false)
      Alert.alert("Éxito", "Viaje solicitado. Buscando conductor...")
    } catch (error: any) {
      Alert.alert("Error", error.response?.data?.message || "Error al solicitar viaje")
    }
  }

  const getMapMarkers = () => {
    const markers = []

    if (originLocation) {
      markers.push({
        id: "origin",
        coordinate: originLocation,
        title: "Origen",
        description: originAddress,
        pinColor: colors.success,
      })
    }

    if (destinationLocation) {
      markers.push({
        id: "destination",
        coordinate: destinationLocation,
        title: "Destino",
        description: destinationAddress,
        pinColor: colors.error,
      })
    }

    return markers
  }

  if (currentTrip) {
    // Si hay un viaje activo, mostrar pantalla de viaje
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.tripActiveContainer}>
          <Text style={styles.tripActiveTitle}>Viaje en curso</Text>
          <Text style={styles.tripActiveStatus}>Estado: {currentTrip.status}</Text>
          {currentTrip.driver && (
            <View style={styles.driverInfo}>
              <Text style={styles.driverName}>
                Conductor: {currentTrip.driver.user.first_name} {currentTrip.driver.user.last_name}
              </Text>
              <Text style={styles.vehicleInfo}>
                {currentTrip.driver.vehicle_brand} {currentTrip.driver.vehicle_model} -{" "}
                {currentTrip.driver.license_plate}
              </Text>
            </View>
          )}
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Hola, {user?.first_name}!</Text>
        <Text style={styles.subtitle}>¿A dónde quieres ir?</Text>
      </View>

      <View style={styles.searchContainer}>
        <AddressSearchInput
          placeholder="¿Desde dónde?"
          onAddressSelect={handleOriginSelect}
          currentLocation={userLocation}
          initialValue={originAddress}
          style={styles.searchInput}
        />

        <AddressSearchInput
          placeholder="¿A dónde vas?"
          onAddressSelect={handleDestinationSelect}
          currentLocation={userLocation}
          style={styles.searchInput}
        />
      </View>

      <View style={styles.mapContainer}>
        <CustomMapView
          initialLocation={userLocation}
          markers={getMapMarkers()}
          showUserLocation={true}
          followUserLocation={false}
        />
      </View>

      <TouchableOpacity style={styles.locationButton} onPress={getCurrentLocation}>
        <Icon name="my-location" size={24} color={colors.primary} />
      </TouchableOpacity>

      {/* Modal de confirmación de viaje */}
      <Modal visible={showTripModal} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Confirmar viaje</Text>

            <View style={styles.tripDetails}>
              <View style={styles.tripDetailRow}>
                <Icon name="radio-button-checked" size={16} color={colors.success} />
                <Text style={styles.tripDetailText} numberOfLines={2}>
                  {originAddress}
                </Text>
              </View>

              <View style={styles.tripDetailRow}>
                <Icon name="place" size={16} color={colors.error} />
                <Text style={styles.tripDetailText} numberOfLines={2}>
                  {destinationAddress}
                </Text>
              </View>

              <View style={styles.costContainer}>
                <Text style={styles.costLabel}>Costo estimado:</Text>
                <Text style={styles.costValue}>${estimatedCost.toFixed(2)}</Text>
              </View>
            </View>

            <View style={styles.paymentMethodContainer}>
              <Text style={styles.paymentMethodLabel}>Método de pago:</Text>
              <View style={styles.paymentMethods}>
                <TouchableOpacity
                  style={[styles.paymentMethod, paymentMethod === "cash" && styles.paymentMethodActive]}
                  onPress={() => setPaymentMethod("cash")}
                >
                  <Icon name="money" size={20} color={paymentMethod === "cash" ? colors.textLight : colors.gray500} />
                  <Text style={[styles.paymentMethodText, paymentMethod === "cash" && styles.paymentMethodTextActive]}>
                    Efectivo
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.paymentMethod, paymentMethod === "mobile_payment" && styles.paymentMethodActive]}
                  onPress={() => setPaymentMethod("mobile_payment")}
                >
                  <Icon
                    name="phone-android"
                    size={20}
                    color={paymentMethod === "mobile_payment" ? colors.textLight : colors.gray500}
                  />
                  <Text
                    style={[
                      styles.paymentMethodText,
                      paymentMethod === "mobile_payment" && styles.paymentMethodTextActive,
                    ]}
                  >
                    Pago Móvil
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowTripModal(false)}>
                <Text style={styles.cancelButtonText}>Cancelar</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.confirmButton, isLoading && styles.disabledButton]}
                onPress={handleRequestTrip}
                disabled={isLoading}
              >
                <Text style={styles.confirmButtonText}>{isLoading ? "Solicitando..." : "Solicitar viaje"}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  greeting: {
    fontSize: typography.sizes["2xl"],
    fontWeight: typography.weights.bold,
    color: colors.text,
  },
  subtitle: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  searchContainer: {
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  searchInput: {
    zIndex: 1000,
  },
  mapContainer: {
    flex: 1,
    margin: spacing.lg,
    borderRadius: 12,
    overflow: "hidden",
  },
  locationButton: {
    position: "absolute",
    bottom: spacing.xl,
    right: spacing.lg,
    backgroundColor: colors.background,
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
    elevation: 4,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  tripActiveContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: spacing.lg,
  },
  tripActiveTitle: {
    fontSize: typography.sizes["2xl"],
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  tripActiveStatus: {
    fontSize: typography.sizes.lg,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
  },
  driverInfo: {
    alignItems: "center",
  },
  driverName: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  vehicleInfo: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: colors.overlay,
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: spacing.lg,
    maxHeight: "80%",
  },
  modalTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    textAlign: "center",
    marginBottom: spacing.lg,
  },
  tripDetails: {
    marginBottom: spacing.lg,
  },
  tripDetailRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: spacing.md,
  },
  tripDetailText: {
    flex: 1,
    fontSize: typography.sizes.base,
    color: colors.text,
    marginLeft: spacing.md,
    lineHeight: typography.lineHeights.normal * typography.sizes.base,
  },
  costContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.gray200,
  },
  costLabel: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  costValue: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.primary,
  },
  paymentMethodContainer: {
    marginBottom: spacing.lg,
  },
  paymentMethodLabel: {
    fontSize: typography.sizes.base,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  paymentMethods: {
    flexDirection: "row",
    gap: spacing.md,
  },
  paymentMethod: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.gray300,
  },
  paymentMethodActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  paymentMethodText: {
    fontSize: typography.sizes.base,
    color: colors.gray500,
    marginLeft: spacing.sm,
  },
  paymentMethodTextActive: {
    color: colors.textLight,
  },
  modalButtons: {
    flexDirection: "row",
    gap: spacing.md,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.gray300,
    alignItems: "center",
  },
  cancelButtonText: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    fontWeight: typography.weights.semibold,
  },
  confirmButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: 12,
    backgroundColor: colors.primary,
    alignItems: "center",
  },
  disabledButton: {
    opacity: 0.6,
  },
  confirmButtonText: {
    fontSize: typography.sizes.base,
    color: colors.textLight,
    fontWeight: typography.weights.semibold,
  },
})

export default HomeScreen
