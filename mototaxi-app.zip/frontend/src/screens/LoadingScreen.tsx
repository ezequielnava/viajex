import type React from "react"
import { View, ActivityIndicator, Text, StyleSheet } from "react-native"
import { colors } from "../styles/colors"
import { typography } from "../styles/typography"

const LoadingScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={styles.text}>Cargando...</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.background,
  },
  text: {
    marginTop: 16,
    fontSize: typography.sizes.lg,
    color: colors.textSecondary,
  },
})

export default LoadingScreen
