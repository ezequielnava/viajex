"use client"

import type React from "react"
import { useState } from "react"
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from "react-native"
import type { StackNavigationProp } from "@react-navigation/stack"
import type { AuthStackParamList } from "../../navigation/AuthNavigator"
import { useAuth } from "../../context/AuthContext"
import { colors } from "../../styles/colors"
import { typography } from "../../styles/typography"
import { spacing } from "../../styles/spacing"

type RegisterScreenNavigationProp = StackNavigationProp<AuthStackParamList, "Register">

interface Props {
  navigation: RegisterScreenNavigationProp
}

const RegisterScreen: React.FC<Props> = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    password_confirm: "",
    first_name: "",
    last_name: "",
    phone_number: "",
    user_type: "passenger" as "passenger" | "driver",
  })
  const [isLoading, setIsLoading] = useState(false)

  const { register } = useAuth()

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateForm = () => {
    const { username, email, password, password_confirm, first_name, last_name, phone_number } = formData

    if (
      !username.trim() ||
      !email.trim() ||
      !password.trim() ||
      !first_name.trim() ||
      !last_name.trim() ||
      !phone_number.trim()
    ) {
      Alert.alert("Error", "Por favor completa todos los campos")
      return false
    }

    if (password !== password_confirm) {
      Alert.alert("Error", "Las contraseñas no coinciden")
      return false
    }

    if (password.length < 8) {
      Alert.alert("Error", "La contraseña debe tener al menos 8 caracteres")
      return false
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      Alert.alert("Error", "Por favor ingresa un email válido")
      return false
    }

    return true
  }

  const handleRegister = async () => {
    if (!validateForm()) return

    try {
      setIsLoading(true)
      await register(formData)
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || "Error al registrar usuario. Intenta nuevamente."
      Alert.alert("Error de registro", errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.keyboardView}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <View style={styles.content}>
            <View style={styles.header}>
              <Text style={styles.title}>Crear Cuenta</Text>
              <Text style={styles.subtitle}>Completa tus datos para registrarte</Text>
            </View>

            <View style={styles.form}>
              <View style={styles.row}>
                <View style={[styles.inputContainer, styles.halfWidth]}>
                  <Text style={styles.label}>Nombre</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.first_name}
                    onChangeText={(value) => handleInputChange("first_name", value)}
                    placeholder="Tu nombre"
                    placeholderTextColor={colors.gray400}
                  />
                </View>

                <View style={[styles.inputContainer, styles.halfWidth]}>
                  <Text style={styles.label}>Apellido</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.last_name}
                    onChangeText={(value) => handleInputChange("last_name", value)}
                    placeholder="Tu apellido"
                    placeholderTextColor={colors.gray400}
                  />
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Usuario</Text>
                <TextInput
                  style={styles.input}
                  value={formData.username}
                  onChangeText={(value) => handleInputChange("username", value)}
                  placeholder="Nombre de usuario"
                  placeholderTextColor={colors.gray400}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Email</Text>
                <TextInput
                  style={styles.input}
                  value={formData.email}
                  onChangeText={(value) => handleInputChange("email", value)}
                  placeholder="tu@email.com"
                  placeholderTextColor={colors.gray400}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Teléfono</Text>
                <TextInput
                  style={styles.input}
                  value={formData.phone_number}
                  onChangeText={(value) => handleInputChange("phone_number", value)}
                  placeholder="+584121234567"
                  placeholderTextColor={colors.gray400}
                  keyboardType="phone-pad"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Contraseña</Text>
                <TextInput
                  style={styles.input}
                  value={formData.password}
                  onChangeText={(value) => handleInputChange("password", value)}
                  placeholder="Mínimo 8 caracteres"
                  placeholderTextColor={colors.gray400}
                  secureTextEntry
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Confirmar Contraseña</Text>
                <TextInput
                  style={styles.input}
                  value={formData.password_confirm}
                  onChangeText={(value) => handleInputChange("password_confirm", value)}
                  placeholder="Repite tu contraseña"
                  placeholderTextColor={colors.gray400}
                  secureTextEntry
                />
              </View>

              <View style={styles.userTypeContainer}>
                <Text style={styles.label}>Tipo de cuenta</Text>
                <View style={styles.userTypeButtons}>
                  <TouchableOpacity
                    style={[styles.userTypeButton, formData.user_type === "passenger" && styles.userTypeButtonActive]}
                    onPress={() => handleInputChange("user_type", "passenger")}
                  >
                    <Text
                      style={[
                        styles.userTypeButtonText,
                        formData.user_type === "passenger" && styles.userTypeButtonTextActive,
                      ]}
                    >
                      Pasajero
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.userTypeButton, formData.user_type === "driver" && styles.userTypeButtonActive]}
                    onPress={() => handleInputChange("user_type", "driver")}
                  >
                    <Text
                      style={[
                        styles.userTypeButtonText,
                        formData.user_type === "driver" && styles.userTypeButtonTextActive,
                      ]}
                    >
                      Conductor
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              <TouchableOpacity
                style={[styles.registerButton, isLoading && styles.disabledButton]}
                onPress={handleRegister}
                disabled={isLoading}
              >
                <Text style={styles.registerButtonText}>{isLoading ? "Registrando..." : "Crear Cuenta"}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.footer}>
              <Text style={styles.footerText}>¿Ya tienes una cuenta? </Text>
              <TouchableOpacity onPress={() => navigation.navigate("Login")}>
                <Text style={styles.linkText}>Inicia sesión aquí</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
  },
  header: {
    alignItems: "center",
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: typography.sizes["3xl"],
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    textAlign: "center",
  },
  form: {
    marginBottom: spacing.xl,
  },
  row: {
    flexDirection: "row",
    gap: spacing.md,
  },
  inputContainer: {
    marginBottom: spacing.lg,
  },
  halfWidth: {
    flex: 1,
  },
  label: {
    fontSize: typography.sizes.base,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.gray300,
    borderRadius: 12,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    fontSize: typography.sizes.base,
    color: colors.text,
    backgroundColor: colors.background,
  },
  userTypeContainer: {
    marginBottom: spacing.lg,
  },
  userTypeButtons: {
    flexDirection: "row",
    gap: spacing.md,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.gray300,
    alignItems: "center",
  },
  userTypeButtonActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  userTypeButtonText: {
    fontSize: typography.sizes.base,
    fontWeight: typography.weights.medium,
    color: colors.textSecondary,
  },
  userTypeButtonTextActive: {
    color: colors.textLight,
  },
  registerButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: 12,
    alignItems: "center",
    marginTop: spacing.lg,
  },
  disabledButton: {
    opacity: 0.6,
  },
  registerButtonText: {
    color: colors.textLight,
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  footerText: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
  },
  linkText: {
    fontSize: typography.sizes.base,
    color: colors.primary,
    fontWeight: typography.weights.semibold,
  },
})

export default RegisterScreen
