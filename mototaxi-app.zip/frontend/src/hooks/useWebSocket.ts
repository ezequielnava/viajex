"use client"

import { useEffect, useCallback, useRef } from "react"
import WebSocketService from "../services/WebSocketService"
import NotificationService from "../services/NotificationService"
import { useAuth } from "../context/AuthContext"

export const useWebSocket = () => {
  const { user, isAuthenticated } = useAuth()
  const isConnected = useRef(false)

  const connect = useCallback(async () => {
    if (!isAuthenticated || isConnected.current) return

    try {
      await WebSocketService.connect()
      isConnected.current = true
      console.log("[v0] WebSocket connected via hook")
    } catch (error) {
      console.error("[v0] WebSocket connection failed via hook:", error)
      isConnected.current = false
    }
  }, [isAuthenticated])

  const disconnect = useCallback(() => {
    if (isConnected.current) {
      WebSocketService.disconnect()
      isConnected.current = false
      console.log("[v0] WebSocket disconnected via hook")
    }
  }, [])

  useEffect(() => {
    if (isAuthenticated && user) {
      connect()
    } else {
      disconnect()
    }

    return () => {
      disconnect()
    }
  }, [isAuthenticated, user, connect, disconnect])

  return {
    connect,
    disconnect,
    isConnected: isConnected.current,
    sendMessage: WebSocketService.sendMessage.bind(WebSocketService),
    on: WebSocketService.on.bind(WebSocketService),
    off: WebSocketService.off.bind(WebSocketService),
  }
}

export const useTripWebSocket = (tripId?: number) => {
  const { isConnected, on, off } = useWebSocket()

  const joinTripRoom = useCallback(() => {
    if (tripId && isConnected) {
      WebSocketService.joinTripRoom(tripId)
    }
  }, [tripId, isConnected])

  const leaveTripRoom = useCallback(() => {
    if (tripId && isConnected) {
      WebSocketService.leaveTripRoom(tripId)
    }
  }, [tripId, isConnected])

  const sendChatMessage = useCallback(
    (message: string) => {
      if (tripId && isConnected) {
        WebSocketService.sendChatMessage(tripId, message)
      }
    },
    [tripId, isConnected],
  )

  useEffect(() => {
    if (tripId && isConnected) {
      joinTripRoom()

      // Set up notification handlers
      const handleTripUpdate = (data: any) => {
        if (data.trip_id === tripId) {
          switch (data.status) {
            case "accepted":
              NotificationService.showTripAcceptedNotification(data.driver_name, data.estimated_arrival)
              break
            case "driver_arrived":
              NotificationService.showDriverArrivedNotification()
              break
            case "cancelled":
              NotificationService.showTripCancelledNotification(data.reason)
              break
            case "completed":
              NotificationService.showTripCompletedNotification(data.final_cost)
              break
          }
        }
      }

      const handleNewMessage = (data: any) => {
        if (data.trip_id === tripId) {
          NotificationService.showNewMessageNotification(data.sender_name, data.message)
        }
      }

      on("trip_update", handleTripUpdate)
      on("new_message", handleNewMessage)

      return () => {
        off("trip_update", handleTripUpdate)
        off("new_message", handleNewMessage)
        leaveTripRoom()
      }
    }
  }, [tripId, isConnected, joinTripRoom, leaveTripRoom, on, off])

  return {
    joinTripRoom,
    leaveTripRoom,
    sendChatMessage,
    isConnected,
  }
}

export const useDriverWebSocket = () => {
  const { isConnected } = useWebSocket()

  const updateLocation = useCallback(
    (location: { latitude: number; longitude: number }) => {
      if (isConnected) {
        WebSocketService.updateDriverLocation(location)
      }
    },
    [isConnected],
  )

  const updateStatus = useCallback(
    (status: "available" | "busy" | "offline") => {
      if (isConnected) {
        WebSocketService.updateDriverStatus(status)
      }
    },
    [isConnected],
  )

  return {
    updateLocation,
    updateStatus,
    isConnected,
  }
}
