export interface User {
  id: number
  username: string
  email: string
  first_name: string
  last_name: string
  phone_number: string
  profile_picture?: string
  user_type: "passenger" | "driver"
  is_verified: boolean
  average_rating: number
  total_ratings: number
  created_at: string
}

export interface Driver {
  id: number
  user: User
  vehicle_type: "motorcycle" | "scooter"
  vehicle_brand: string
  vehicle_model: string
  vehicle_year: number
  vehicle_color: string
  license_plate: string
  status: "offline" | "online" | "busy"
  is_available: boolean
  is_verified: boolean
  total_trips: number
  total_earnings: number
}

export interface Trip {
  id: number
  trip_id: string
  passenger: User
  driver?: Driver
  origin_address: string
  origin_latitude: number
  origin_longitude: number
  destination_address: string
  destination_latitude: number
  destination_longitude: number
  distance_km: number
  estimated_duration_minutes: number
  estimated_cost: number
  final_cost?: number
  status: "requested" | "accepted" | "driver_arrived" | "in_progress" | "completed" | "cancelled"
  payment_method: "cash" | "mobile_payment"
  is_paid: boolean
  passenger_notes?: string
  driver_notes?: string
  requested_at: string
  accepted_at?: string
  started_at?: string
  completed_at?: string
  cancelled_at?: string
}

export interface Location {
  latitude: number
  longitude: number
}

export interface AuthTokens {
  access: string
  refresh: string
}

export interface LoginCredentials {
  username: string
  password: string
}

export interface RegisterData {
  username: string
  email: string
  password: string
  password_confirm: string
  first_name: string
  last_name: string
  phone_number: string
  user_type: "passenger" | "driver"
}

export interface TripRequest {
  origin_address: string
  origin_latitude: number
  origin_longitude: number
  destination_address: string
  destination_latitude: number
  destination_longitude: number
  payment_method: "cash" | "mobile_payment"
  passenger_notes?: string
}
