export const colors = {
  // Colores principales
  primary: "#2E86AB", // Azul principal
  secondary: "#A23B72", // Rosa/morado secundario
  accent: "#F18F01", // Naranja para acentos

  // Colores neutros
  background: "#FFFFFF",
  surface: "#F8F9FA",
  card: "#FFFFFF",

  // Colores de texto
  text: "#212529",
  textSecondary: "#6C757D",
  textLight: "#FFFFFF",

  // Estados
  success: "#28A745",
  warning: "#FFC107",
  error: "#DC3545",
  info: "#17A2B8",

  // Grises
  gray100: "#F8F9FA",
  gray200: "#E9ECEF",
  gray300: "#DEE2E6",
  gray400: "#CED4DA",
  gray500: "#ADB5BD",
  gray600: "#6C757D",
  gray700: "#495057",
  gray800: "#343A40",
  gray900: "#212529",

  // Transparencias
  overlay: "rgba(0, 0, 0, 0.5)",
  shadow: "rgba(0, 0, 0, 0.1)",
}
