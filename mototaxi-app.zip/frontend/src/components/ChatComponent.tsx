"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from "react-native"
import Icon from "react-native-vector-icons/MaterialIcons"
import { useTripWebSocket } from "../hooks/useWebSocket"
import { colors } from "../styles/colors"
import { typography } from "../styles/typography"
import { spacing } from "../styles/spacing"

interface Message {
  id: string
  message: string
  sender_name: string
  sender_type: "user" | "driver"
  timestamp: string
  is_own: boolean
}

interface ChatComponentProps {
  tripId: number
  currentUserType: "user" | "driver"
}

const ChatComponent: React.FC<ChatComponentProps> = ({ tripId, currentUserType }) => {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const flatListRef = useRef<FlatList>(null)
  const { sendChatMessage, isConnected, on, off } = useTripWebSocket(tripId)

  useEffect(() => {
    const handleNewMessage = (data: any) => {
      if (data.trip_id === tripId) {
        const message: Message = {
          id: data.id || Date.now().toString(),
          message: data.message,
          sender_name: data.sender_name,
          sender_type: data.sender_type,
          timestamp: data.timestamp || new Date().toISOString(),
          is_own: data.sender_type === currentUserType,
        }
        setMessages((prev) => [...prev, message])

        // Scroll to bottom
        setTimeout(() => {
          flatListRef.current?.scrollToEnd({ animated: true })
        }, 100)
      }
    }

    on("new_message", handleNewMessage)

    return () => {
      off("new_message", handleNewMessage)
    }
  }, [tripId, currentUserType, on, off])

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !isConnected || isLoading) return

    setIsLoading(true)
    try {
      // Add message optimistically
      const tempMessage: Message = {
        id: Date.now().toString(),
        message: newMessage.trim(),
        sender_name: "Tú",
        sender_type: currentUserType,
        timestamp: new Date().toISOString(),
        is_own: true,
      }

      setMessages((prev) => [...prev, tempMessage])
      sendChatMessage(newMessage.trim())
      setNewMessage("")

      // Scroll to bottom
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true })
      }, 100)
    } catch (error) {
      console.error("[v0] Error sending message:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleTimeString("es-ES", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const renderMessage = ({ item }: { item: Message }) => (
    <View style={[styles.messageContainer, item.is_own ? styles.ownMessage : styles.otherMessage]}>
      <View style={[styles.messageBubble, item.is_own ? styles.ownBubble : styles.otherBubble]}>
        {!item.is_own && <Text style={styles.senderName}>{item.sender_name}</Text>}
        <Text style={[styles.messageText, item.is_own ? styles.ownMessageText : styles.otherMessageText]}>
          {item.message}
        </Text>
        <Text style={[styles.messageTime, item.is_own ? styles.ownMessageTime : styles.otherMessageTime]}>
          {formatTime(item.timestamp)}
        </Text>
      </View>
    </View>
  )

  const renderEmptyState = () => (
    <View style={styles.emptyState}>
      <Icon name="chat" size={48} color={colors.gray400} />
      <Text style={styles.emptyStateText}>
        Inicia una conversación con tu {currentUserType === "user" ? "conductor" : "pasajero"}
      </Text>
    </View>
  )

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesContainer}
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={newMessage}
          onChangeText={setNewMessage}
          placeholder="Escribe un mensaje..."
          placeholderTextColor={colors.gray400}
          multiline
          maxLength={500}
          editable={isConnected && !isLoading}
        />
        <TouchableOpacity
          style={[styles.sendButton, (!newMessage.trim() || !isConnected || isLoading) && styles.sendButtonDisabled]}
          onPress={handleSendMessage}
          disabled={!newMessage.trim() || !isConnected || isLoading}
        >
          <Icon
            name="send"
            size={20}
            color={!newMessage.trim() || !isConnected || isLoading ? colors.gray400 : colors.white}
          />
        </TouchableOpacity>
      </View>

      {!isConnected && (
        <View style={styles.connectionStatus}>
          <Text style={styles.connectionStatusText}>Conectando al chat...</Text>
        </View>
      )}
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  messagesContainer: {
    flexGrow: 1,
    padding: spacing.md,
  },
  messageContainer: {
    marginBottom: spacing.sm,
  },
  ownMessage: {
    alignItems: "flex-end",
  },
  otherMessage: {
    alignItems: "flex-start",
  },
  messageBubble: {
    maxWidth: "80%",
    padding: spacing.sm,
    borderRadius: 16,
  },
  ownBubble: {
    backgroundColor: colors.primary,
    borderBottomRightRadius: 4,
  },
  otherBubble: {
    backgroundColor: colors.gray200,
    borderBottomLeftRadius: 4,
  },
  senderName: {
    fontSize: typography.sizes.xs,
    fontWeight: typography.weights.semibold,
    color: colors.gray600,
    marginBottom: spacing.xs,
  },
  messageText: {
    fontSize: typography.sizes.base,
    lineHeight: 20,
  },
  ownMessageText: {
    color: colors.white,
  },
  otherMessageText: {
    color: colors.text,
  },
  messageTime: {
    fontSize: typography.sizes.xs,
    marginTop: spacing.xs,
  },
  ownMessageTime: {
    color: colors.white,
    opacity: 0.8,
  },
  otherMessageTime: {
    color: colors.gray500,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    padding: spacing.md,
    backgroundColor: colors.card,
    borderTopWidth: 1,
    borderTopColor: colors.gray200,
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.gray300,
    borderRadius: 20,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginRight: spacing.sm,
    maxHeight: 100,
    fontSize: typography.sizes.base,
    color: colors.text,
    backgroundColor: colors.background,
  },
  sendButton: {
    backgroundColor: colors.primary,
    borderRadius: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  sendButtonDisabled: {
    backgroundColor: colors.gray300,
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: spacing.xl,
  },
  emptyStateText: {
    fontSize: typography.sizes.base,
    color: colors.textSecondary,
    textAlign: "center",
    marginTop: spacing.md,
    lineHeight: 24,
  },
  connectionStatus: {
    backgroundColor: colors.warning,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    alignItems: "center",
  },
  connectionStatusText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: typography.weights.semibold,
  },
})

export default ChatComponent
