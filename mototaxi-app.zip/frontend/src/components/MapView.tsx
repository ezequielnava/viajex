"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import { View, StyleSheet } from "react-native"
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from "react-native-maps"
import type { Location } from "../types"
import { colors } from "../styles/colors"

interface MapViewProps {
  initialLocation?: Location
  markers?: Array<{
    id: string
    coordinate: Location
    title?: string
    description?: string
    pinColor?: string
  }>
  polylineCoordinates?: Location[]
  onMapPress?: (coordinate: Location) => void
  onMarkerPress?: (markerId: string) => void
  showUserLocation?: boolean
  followUserLocation?: boolean
  style?: any
}

const CustomMapView: React.FC<MapViewProps> = ({
  initialLocation,
  markers = [],
  polylineCoordinates = [],
  onMapPress,
  onMarkerPress,
  showUserLocation = true,
  followUserLocation = false,
  style,
}) => {
  const mapRef = useRef<MapView>(null)
  const [region, setRegion] = useState({
    latitude: initialLocation?.latitude || 10.4806, // Caracas por defecto
    longitude: initialLocation?.longitude || -66.9036,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  })

  useEffect(() => {
    if (initialLocation) {
      setRegion({
        latitude: initialLocation.latitude,
        longitude: initialLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      })
    }
  }, [initialLocation])

  useEffect(() => {
    if (followUserLocation && initialLocation && mapRef.current) {
      mapRef.current.animateToRegion(
        {
          latitude: initialLocation.latitude,
          longitude: initialLocation.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        },
        1000,
      )
    }
  }, [initialLocation, followUserLocation])

  const handleMapPress = (event: any) => {
    if (onMapPress) {
      const coordinate = event.nativeEvent.coordinate
      onMapPress(coordinate)
    }
  }

  const handleMarkerPress = (markerId: string) => {
    if (onMarkerPress) {
      onMarkerPress(markerId)
    }
  }

  const fitToMarkers = () => {
    if (markers.length > 0 && mapRef.current) {
      mapRef.current.fitToCoordinates(
        markers.map((marker) => marker.coordinate),
        {
          edgePadding: { top: 50, right: 50, bottom: 50, left: 50 },
          animated: true,
        },
      )
    }
  }

  useEffect(() => {
    if (markers.length > 1) {
      setTimeout(fitToMarkers, 1000)
    }
  }, [markers])

  return (
    <View style={[styles.container, style]}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        region={region}
        onRegionChangeComplete={setRegion}
        onPress={handleMapPress}
        showsUserLocation={showUserLocation}
        showsMyLocationButton={true}
        showsCompass={true}
        showsScale={true}
        mapType="standard"
      >
        {markers.map((marker) => (
          <Marker
            key={marker.id}
            coordinate={marker.coordinate}
            title={marker.title}
            description={marker.description}
            pinColor={marker.pinColor || colors.primary}
            onPress={() => handleMarkerPress(marker.id)}
          />
        ))}

        {polylineCoordinates.length > 1 && (
          <Polyline
            coordinates={polylineCoordinates}
            strokeColor={colors.primary}
            strokeWidth={4}
            lineDashPattern={[1]}
          />
        )}
      </MapView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
})

export default CustomMapView
