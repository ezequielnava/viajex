"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, TextInput, FlatList, TouchableOpacity, Text, StyleSheet, ActivityIndicator } from "react-native"
import Icon from "react-native-vector-icons/MaterialIcons"
import { geocodingService, type Address } from "../services/GeocodingService"
import type { Location } from "../types"
import { colors } from "../styles/colors"
import { typography } from "../styles/typography"
import { spacing } from "../styles/spacing"

interface AddressSearchInputProps {
  placeholder?: string
  onAddressSelect: (address: string, location: Location) => void
  currentLocation?: Location
  initialValue?: string
  style?: any
}

const AddressSearchInput: React.FC<AddressSearchInputProps> = ({
  placeholder = "Buscar dirección...",
  onAddressSelect,
  currentLocation,
  initialValue = "",
  style,
}) => {
  const [query, setQuery] = useState(initialValue)
  const [results, setResults] = useState<Address[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showResults, setShowResults] = useState(false)

  useEffect(() => {
    const searchTimeout = setTimeout(() => {
      if (query.trim().length > 2) {
        searchAddresses(query)
      } else {
        setResults([])
        setShowResults(false)
      }
    }, 500)

    return () => clearTimeout(searchTimeout)
  }, [query])

  const searchAddresses = async (searchQuery: string) => {
    try {
      setIsLoading(true)
      const addresses = await geocodingService.searchPlaces(searchQuery, currentLocation)
      setResults(addresses)
      setShowResults(true)
    } catch (error) {
      console.error("Error searching addresses:", error)
      setResults([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddressSelect = (address: Address) => {
    setQuery(address.formatted_address)
    setShowResults(false)
    onAddressSelect(address.formatted_address, address.geometry.location)
  }

  const clearInput = () => {
    setQuery("")
    setResults([])
    setShowResults(false)
  }

  const renderAddressItem = ({ item }: { item: Address }) => (
    <TouchableOpacity style={styles.resultItem} onPress={() => handleAddressSelect(item)}>
      <Icon name="place" size={20} color={colors.gray500} style={styles.resultIcon} />
      <Text style={styles.resultText} numberOfLines={2}>
        {item.formatted_address}
      </Text>
    </TouchableOpacity>
  )

  return (
    <View style={[styles.container, style]}>
      <View style={styles.inputContainer}>
        <Icon name="search" size={20} color={colors.gray500} style={styles.searchIcon} />
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          placeholder={placeholder}
          placeholderTextColor={colors.gray400}
          onFocus={() => {
            if (results.length > 0) {
              setShowResults(true)
            }
          }}
        />
        {isLoading && <ActivityIndicator size="small" color={colors.primary} style={styles.loadingIcon} />}
        {query.length > 0 && !isLoading && (
          <TouchableOpacity onPress={clearInput} style={styles.clearButton}>
            <Icon name="clear" size={20} color={colors.gray500} />
          </TouchableOpacity>
        )}
      </View>

      {showResults && results.length > 0 && (
        <View style={styles.resultsContainer}>
          <FlatList
            data={results}
            renderItem={renderAddressItem}
            keyExtractor={(item, index) => item.place_id || index.toString()}
            style={styles.resultsList}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          />
        </View>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
    zIndex: 1000,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.background,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.gray300,
    paddingHorizontal: spacing.md,
    height: 48,
  },
  searchIcon: {
    marginRight: spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: typography.sizes.base,
    color: colors.text,
    paddingVertical: 0,
  },
  loadingIcon: {
    marginLeft: spacing.sm,
  },
  clearButton: {
    marginLeft: spacing.sm,
    padding: spacing.xs,
  },
  resultsContainer: {
    position: "absolute",
    top: 52,
    left: 0,
    right: 0,
    backgroundColor: colors.background,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.gray300,
    maxHeight: 200,
    zIndex: 1001,
  },
  resultsList: {
    flex: 1,
  },
  resultItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray200,
  },
  resultIcon: {
    marginRight: spacing.md,
  },
  resultText: {
    flex: 1,
    fontSize: typography.sizes.base,
    color: colors.text,
    lineHeight: typography.lineHeights.normal * typography.sizes.base,
  },
})

export default AddressSearchInput
