import PushNotification, { Importance } from "react-native-push-notification"
import PushNotificationIOS from "@react-native-community/push-notification-ios"
import { Platform, PermissionsAndroid } from "react-native"
import AsyncStorage from "@react-native-async-storage/async-storage"

export interface NotificationData {
  title: string
  message: string
  data?: any
  sound?: boolean
  vibrate?: boolean
  priority?: "high" | "normal" | "low"
}

class NotificationService {
  private initialized = false

  async initialize(): Promise<void> {
    if (this.initialized) return

    // Configure push notifications
    PushNotification.configure({
      onRegister: async (token) => {
        console.log("[v0] Push notification token:", token)
        await AsyncStorage.setItem("push_token", token.token)
      },

      onNotification: (notification) => {
        console.log("[v0] Notification received:", notification)

        if (Platform.OS === "ios") {
          notification.finish(PushNotificationIOS.FetchResult.NoData)
        }
      },

      onAction: (notification) => {
        console.log("[v0] Notification action:", notification.action)
      },

      onRegistrationError: (err) => {
        console.error("[v0] Push notification registration error:", err)
      },

      permissions: {
        alert: true,
        badge: true,
        sound: true,
      },

      popInitialNotification: true,
      requestPermissions: Platform.OS === "ios",
    })

    // Request permissions for Android
    if (Platform.OS === "android") {
      await this.requestAndroidPermissions()
    }

    // Create notification channels for Android
    this.createNotificationChannels()

    this.initialized = true
  }

  private async requestAndroidPermissions(): Promise<void> {
    try {
      if (Platform.Version >= 33) {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS)
        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
          console.warn("[v0] Notification permission denied")
        }
      }
    } catch (error) {
      console.error("[v0] Error requesting notification permissions:", error)
    }
  }

  private createNotificationChannels(): void {
    if (Platform.OS === "android") {
      PushNotification.createChannel(
        {
          channelId: "trip-updates",
          channelName: "Trip Updates",
          channelDescription: "Notifications about trip status changes",
          importance: Importance.HIGH,
          vibrate: true,
        },
        (created) => console.log("[v0] Trip updates channel created:", created),
      )

      PushNotification.createChannel(
        {
          channelId: "driver-messages",
          channelName: "Driver Messages",
          channelDescription: "Messages from drivers",
          importance: Importance.HIGH,
          vibrate: true,
        },
        (created) => console.log("[v0] Driver messages channel created:", created),
      )

      PushNotification.createChannel(
        {
          channelId: "general",
          channelName: "General",
          channelDescription: "General notifications",
          importance: Importance.DEFAULT,
          vibrate: false,
        },
        (created) => console.log("[v0] General channel created:", created),
      )
    }
  }

  async showLocalNotification(data: NotificationData): Promise<void> {
    if (!this.initialized) {
      await this.initialize()
    }

    const channelId = this.getChannelId(data.data?.type)

    PushNotification.localNotification({
      title: data.title,
      message: data.message,
      playSound: data.sound !== false,
      soundName: "default",
      vibrate: data.vibrate !== false,
      vibration: 300,
      channelId,
      userInfo: data.data,
      priority: data.priority === "high" ? "high" : "default",
      importance: data.priority === "high" ? "high" : "default",
    })
  }

  private getChannelId(type?: string): string {
    switch (type) {
      case "trip_update":
      case "trip_accepted":
      case "trip_cancelled":
      case "driver_arrived":
        return "trip-updates"
      case "new_message":
        return "driver-messages"
      default:
        return "general"
    }
  }

  async getPushToken(): Promise<string | null> {
    return await AsyncStorage.getItem("push_token")
  }

  cancelAllNotifications(): void {
    PushNotification.cancelAllLocalNotifications()
  }

  cancelNotification(id: string): void {
    PushNotification.cancelLocalNotifications({ id })
  }

  // Notification templates
  async showTripAcceptedNotification(driverName: string, estimatedArrival: string): Promise<void> {
    await this.showLocalNotification({
      title: "¡Viaje Aceptado!",
      message: `${driverName} aceptó tu viaje. Llegará en ${estimatedArrival}`,
      data: { type: "trip_accepted" },
      priority: "high",
    })
  }

  async showDriverArrivedNotification(): Promise<void> {
    await this.showLocalNotification({
      title: "Tu conductor ha llegado",
      message: "Tu conductor está esperándote en el punto de recogida",
      data: { type: "driver_arrived" },
      priority: "high",
    })
  }

  async showTripCancelledNotification(reason?: string): Promise<void> {
    await this.showLocalNotification({
      title: "Viaje Cancelado",
      message: reason || "Tu viaje ha sido cancelado",
      data: { type: "trip_cancelled" },
      priority: "high",
    })
  }

  async showNewMessageNotification(senderName: string, message: string): Promise<void> {
    await this.showLocalNotification({
      title: `Mensaje de ${senderName}`,
      message: message,
      data: { type: "new_message" },
      priority: "high",
    })
  }

  async showTripCompletedNotification(cost: number): Promise<void> {
    await this.showLocalNotification({
      title: "Viaje Completado",
      message: `Tu viaje ha terminado. Costo: $${cost.toFixed(2)}`,
      data: { type: "trip_completed" },
    })
  }
}

export default new NotificationService()
