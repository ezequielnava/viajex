import Config from "react-native-config"
import type { Location } from "../types"

export interface Address {
  formatted_address: string
  place_id?: string
  geometry: {
    location: Location
  }
}

export interface GeocodeResult {
  results: Address[]
  status: string
}

class GeocodingService {
  private readonly apiKey: string

  constructor() {
    this.apiKey = Config.GOOGLE_MAPS_API_KEY || ""
  }

  async getAddressFromCoordinates(latitude: number, longitude: number): Promise<string> {
    if (!this.apiKey) {
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
    }

    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${this.apiKey}&language=es`,
      )

      const data: GeocodeResult = await response.json()

      if (data.status === "OK" && data.results.length > 0) {
        return data.results[0].formatted_address
      }

      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
    } catch (error) {
      console.error("Error in reverse geocoding:", error)
      return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
    }
  }

  async getCoordinatesFromAddress(address: string): Promise<Location | null> {
    if (!this.apiKey) {
      return null
    }

    try {
      const encodedAddress = encodeURIComponent(address)
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${this.apiKey}&language=es`,
      )

      const data: GeocodeResult = await response.json()

      if (data.status === "OK" && data.results.length > 0) {
        const location = data.results[0].geometry.location
        return {
          latitude: location.latitude,
          longitude: location.longitude,
        }
      }

      return null
    } catch (error) {
      console.error("Error in geocoding:", error)
      return null
    }
  }

  async searchPlaces(query: string, location?: Location): Promise<Address[]> {
    if (!this.apiKey || !query.trim()) {
      return []
    }

    try {
      let url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(
        query,
      )}&key=${this.apiKey}&language=es`

      if (location) {
        url += `&location=${location.latitude},${location.longitude}&radius=10000`
      }

      const response = await fetch(url)
      const data = await response.json()

      if (data.status === "OK") {
        return data.results.map((result: any) => ({
          formatted_address: result.formatted_address,
          place_id: result.place_id,
          geometry: {
            location: {
              latitude: result.geometry.location.lat,
              longitude: result.geometry.location.lng,
            },
          },
        }))
      }

      return []
    } catch (error) {
      console.error("Error searching places:", error)
      return []
    }
  }
}

export const geocodingService = new GeocodingService()
