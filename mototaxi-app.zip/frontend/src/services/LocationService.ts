import Geolocation from "react-native-geolocation-service"
import { PermissionsAndroid, Platform } from "react-native"
import { PERMISSIONS, request, check, RESULTS } from "react-native-permissions"
import type { Location } from "../types"

export interface LocationError {
  code: number
  message: string
}

class LocationService {
  private watchId: number | null = null

  async requestLocationPermission(): Promise<boolean> {
    try {
      if (Platform.OS === "android") {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION, {
          title: "Permiso de Ubicación",
          message: "MotoTaxi necesita acceso a tu ubicación para funcionar correctamente",
          buttonNeutral: "Preguntar después",
          buttonNegative: "Cancelar",
          buttonPositive: "Aceptar",
        })
        return granted === PermissionsAndroid.RESULTS.GRANTED
      } else {
        const result = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
        return result === RESULTS.GRANTED
      }
    } catch (error) {
      console.error("Error requesting location permission:", error)
      return false
    }
  }

  async checkLocationPermission(): Promise<boolean> {
    try {
      if (Platform.OS === "android") {
        const result = await check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION)
        return result === RESULTS.GRANTED
      } else {
        const result = await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
        return result === RESULTS.GRANTED
      }
    } catch (error) {
      console.error("Error checking location permission:", error)
      return false
    }
  }

  async getCurrentLocation(): Promise<Location> {
    return new Promise((resolve, reject) => {
      const hasPermission = this.checkLocationPermission()

      if (!hasPermission) {
        reject({
          code: 1,
          message: "Permisos de ubicación no otorgados",
        })
        return
      }

      Geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          })
        },
        (error) => {
          reject({
            code: error.code,
            message: this.getLocationErrorMessage(error.code),
          })
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 10000,
        },
      )
    })
  }

  startWatchingLocation(
    onLocationUpdate: (location: Location) => void,
    onError?: (error: LocationError) => void,
  ): void {
    if (this.watchId !== null) {
      this.stopWatchingLocation()
    }

    this.watchId = Geolocation.watchPosition(
      (position) => {
        onLocationUpdate({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        })
      },
      (error) => {
        if (onError) {
          onError({
            code: error.code,
            message: this.getLocationErrorMessage(error.code),
          })
        }
      },
      {
        enableHighAccuracy: true,
        distanceFilter: 10, // Actualizar cada 10 metros
        interval: 5000, // Actualizar cada 5 segundos
        fastestInterval: 2000, // Mínimo 2 segundos entre actualizaciones
      },
    )
  }

  stopWatchingLocation(): void {
    if (this.watchId !== null) {
      Geolocation.clearWatch(this.watchId)
      this.watchId = null
    }
  }

  calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371 // Radio de la Tierra en km
    const dLat = this.deg2rad(lat2 - lat1)
    const dLon = this.deg2rad(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    const distance = R * c // Distancia en km
    return distance
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180)
  }

  private getLocationErrorMessage(code: number): string {
    switch (code) {
      case 1:
        return "Permisos de ubicación denegados"
      case 2:
        return "Ubicación no disponible"
      case 3:
        return "Tiempo de espera agotado"
      default:
        return "Error desconocido al obtener ubicación"
    }
  }

  async requestLocationWithPermission(): Promise<Location> {
    const hasPermission = await this.checkLocationPermission()

    if (!hasPermission) {
      const granted = await this.requestLocationPermission()
      if (!granted) {
        throw {
          code: 1,
          message: "Permisos de ubicación requeridos para usar la aplicación",
        }
      }
    }

    return this.getCurrentLocation()
  }
}

export const locationService = new LocationService()
