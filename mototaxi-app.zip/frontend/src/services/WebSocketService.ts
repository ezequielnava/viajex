import { io, type Socket } from "socket.io-client"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { API_BASE_URL } from "./ApiService"

export interface WebSocketMessage {
  type: string
  data: any
  timestamp: string
}

export interface TripUpdate {
  trip_id: number
  status: string
  driver_location?: {
    latitude: number
    longitude: number
  }
  estimated_arrival?: string
  message?: string
}

class WebSocketService {
  private socket: Socket | null = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 1000
  private listeners: Map<string, ((data: any) => void)[]> = new Map()

  async connect(): Promise<void> {
    try {
      const token = await AsyncStorage.getItem("access_token")
      if (!token) {
        throw new Error("No authentication token found")
      }

      const wsUrl = API_BASE_URL.replace("http", "ws").replace("https", "wss")

      this.socket = io(wsUrl, {
        auth: {
          token: token,
        },
        transports: ["websocket"],
        upgrade: true,
        rememberUpgrade: true,
        timeout: 20000,
        forceNew: true,
      })

      this.setupEventListeners()

      return new Promise((resolve, reject) => {
        this.socket?.on("connect", () => {
          console.log("[v0] WebSocket connected successfully")
          this.reconnectAttempts = 0
          resolve()
        })

        this.socket?.on("connect_error", (error) => {
          console.log("[v0] WebSocket connection error:", error)
          reject(error)
        })

        setTimeout(() => {
          if (!this.socket?.connected) {
            reject(new Error("WebSocket connection timeout"))
          }
        }, 10000)
      })
    } catch (error) {
      console.error("[v0] WebSocket connection failed:", error)
      throw error
    }
  }

  private setupEventListeners(): void {
    if (!this.socket) return

    this.socket.on("disconnect", (reason) => {
      console.log("[v0] WebSocket disconnected:", reason)
      if (reason === "io server disconnect") {
        // Server disconnected, try to reconnect
        this.handleReconnection()
      }
    })

    this.socket.on("reconnect", (attemptNumber) => {
      console.log("[v0] WebSocket reconnected after", attemptNumber, "attempts")
      this.reconnectAttempts = 0
    })

    this.socket.on("reconnect_error", (error) => {
      console.log("[v0] WebSocket reconnection error:", error)
      this.handleReconnection()
    })

    // Trip-related events
    this.socket.on("trip_update", (data: TripUpdate) => {
      this.emit("trip_update", data)
    })

    this.socket.on("driver_location_update", (data: any) => {
      this.emit("driver_location_update", data)
    })

    this.socket.on("trip_request", (data: any) => {
      this.emit("trip_request", data)
    })

    this.socket.on("trip_accepted", (data: any) => {
      this.emit("trip_accepted", data)
    })

    this.socket.on("trip_cancelled", (data: any) => {
      this.emit("trip_cancelled", data)
    })

    // Chat events
    this.socket.on("new_message", (data: any) => {
      this.emit("new_message", data)
    })

    // Driver events
    this.socket.on("driver_status_update", (data: any) => {
      this.emit("driver_status_update", data)
    })
  }

  private handleReconnection(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log("[v0] Max reconnection attempts reached")
      return
    }

    this.reconnectAttempts++
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1)

    setTimeout(() => {
      console.log("[v0] Attempting to reconnect WebSocket...")
      this.connect().catch((error) => {
        console.error("[v0] Reconnection failed:", error)
      })
    }, delay)
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }
    this.listeners.clear()
  }

  // Event subscription methods
  on(event: string, callback: (data: any) => void): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, [])
    }
    this.listeners.get(event)?.push(callback)
  }

  off(event: string, callback: (data: any) => void): void {
    const eventListeners = this.listeners.get(event)
    if (eventListeners) {
      const index = eventListeners.indexOf(callback)
      if (index > -1) {
        eventListeners.splice(index, 1)
      }
    }
  }

  private emit(event: string, data: any): void {
    const eventListeners = this.listeners.get(event)
    if (eventListeners) {
      eventListeners.forEach((callback) => callback(data))
    }
  }

  // Send methods
  sendMessage(event: string, data: any): void {
    if (this.socket?.connected) {
      this.socket.emit(event, data)
    } else {
      console.warn("[v0] WebSocket not connected, message not sent:", event, data)
    }
  }

  joinTripRoom(tripId: number): void {
    this.sendMessage("join_trip", { trip_id: tripId })
  }

  leaveTripRoom(tripId: number): void {
    this.sendMessage("leave_trip", { trip_id: tripId })
  }

  updateDriverLocation(location: { latitude: number; longitude: number }): void {
    this.sendMessage("update_location", location)
  }

  sendChatMessage(tripId: number, message: string): void {
    this.sendMessage("send_message", {
      trip_id: tripId,
      message: message,
    })
  }

  updateDriverStatus(status: "available" | "busy" | "offline"): void {
    this.sendMessage("update_driver_status", { status })
  }

  isConnected(): boolean {
    return this.socket?.connected || false
  }
}

export default new WebSocketService()
