"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"
import AsyncStorage from "@react-native-async-storage/async-storage"
import type { User, AuthTokens, LoginCredentials, RegisterData } from "../types"
import { authAPI } from "../api/auth"

interface AuthState {
  user: User | null
  tokens: AuthTokens | null
  isLoading: boolean
  isAuthenticated: boolean
}

type AuthAction =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "LOGIN_SUCCESS"; payload: { user: User; tokens: AuthTokens } }
  | { type: "LOGOUT" }
  | { type: "UPDATE_USER"; payload: User }

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>
  register: (data: RegisterData) => Promise<void>
  logout: () => Promise<void>
  updateUser: (user: User) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload }
    case "LOGIN_SUCCESS":
      return {
        ...state,
        user: action.payload.user,
        tokens: action.payload.tokens,
        isAuthenticated: true,
        isLoading: false,
      }
    case "LOGOUT":
      return {
        user: null,
        tokens: null,
        isAuthenticated: false,
        isLoading: false,
      }
    case "UPDATE_USER":
      return { ...state, user: action.payload }
    default:
      return state
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    tokens: null,
    isLoading: true,
    isAuthenticated: false,
  })

  useEffect(() => {
    loadStoredAuth()
  }, [])

  const loadStoredAuth = async () => {
    try {
      const storedTokens = await AsyncStorage.getItem("auth_tokens")
      const storedUser = await AsyncStorage.getItem("user")

      if (storedTokens && storedUser) {
        const tokens = JSON.parse(storedTokens)
        const user = JSON.parse(storedUser)

        dispatch({
          type: "LOGIN_SUCCESS",
          payload: { user, tokens },
        })
      }
    } catch (error) {
      console.error("Error loading stored auth:", error)
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const login = async (credentials: LoginCredentials) => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await authAPI.login(credentials)

      await AsyncStorage.setItem("auth_tokens", JSON.stringify(response.tokens))
      await AsyncStorage.setItem("user", JSON.stringify(response.user))

      dispatch({
        type: "LOGIN_SUCCESS",
        payload: { user: response.user, tokens: response.tokens },
      })
    } catch (error) {
      dispatch({ type: "SET_LOADING", payload: false })
      throw error
    }
  }

  const register = async (data: RegisterData) => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const response = await authAPI.register(data)

      await AsyncStorage.setItem("auth_tokens", JSON.stringify(response.tokens))
      await AsyncStorage.setItem("user", JSON.stringify(response.user))

      dispatch({
        type: "LOGIN_SUCCESS",
        payload: { user: response.user, tokens: response.tokens },
      })
    } catch (error) {
      dispatch({ type: "SET_LOADING", payload: false })
      throw error
    }
  }

  const logout = async () => {
    try {
      await AsyncStorage.removeItem("auth_tokens")
      await AsyncStorage.removeItem("user")
      dispatch({ type: "LOGOUT" })
    } catch (error) {
      console.error("Error during logout:", error)
    }
  }

  const updateUser = (user: User) => {
    dispatch({ type: "UPDATE_USER", payload: user })
    AsyncStorage.setItem("user", JSON.stringify(user))
  }

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
