"use client"

import type React from "react"
import { createContext, useContext, useReducer, useEffect } from "react"
import type { Trip, TripRequest, Location } from "../types"
import { tripAPI } from "../api/trips"
import { useAuth } from "./AuthContext"

interface TripState {
  currentTrip: Trip | null
  tripHistory: Trip[]
  isLoading: boolean
  driverLocation: Location | null
}

type TripAction =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_CURRENT_TRIP"; payload: Trip | null }
  | { type: "UPDATE_TRIP"; payload: Trip }
  | { type: "SET_TRIP_HISTORY"; payload: Trip[] }
  | { type: "SET_DRIVER_LOCATION"; payload: Location | null }

interface TripContextType extends TripState {
  requestTrip: (tripData: TripRequest) => Promise<Trip>
  cancelTrip: (tripId: number, reason: string) => Promise<void>
  acceptTrip: (tripId: number) => Promise<void>
  completeTrip: (tripId: number) => Promise<void>
  updateTripStatus: (tripId: number, status: string) => Promise<void>
  loadCurrentTrip: () => Promise<void>
  loadTripHistory: () => Promise<void>
  updateDriverLocation: (location: Location) => void
}

const TripContext = createContext<TripContextType | undefined>(undefined)

const tripReducer = (state: TripState, action: TripAction): TripState => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload }
    case "SET_CURRENT_TRIP":
      return { ...state, currentTrip: action.payload }
    case "UPDATE_TRIP":
      return {
        ...state,
        currentTrip: state.currentTrip?.id === action.payload.id ? action.payload : state.currentTrip,
      }
    case "SET_TRIP_HISTORY":
      return { ...state, tripHistory: action.payload }
    case "SET_DRIVER_LOCATION":
      return { ...state, driverLocation: action.payload }
    default:
      return state
  }
}

export const TripProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(tripReducer, {
    currentTrip: null,
    tripHistory: [],
    isLoading: false,
    driverLocation: null,
  })

  const { isAuthenticated } = useAuth()

  useEffect(() => {
    if (isAuthenticated) {
      loadCurrentTrip()
    }
  }, [isAuthenticated])

  const requestTrip = async (tripData: TripRequest): Promise<Trip> => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const trip = await tripAPI.requestTrip(tripData)
      dispatch({ type: "SET_CURRENT_TRIP", payload: trip })
      return trip
    } catch (error) {
      throw error
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const cancelTrip = async (tripId: number, reason: string) => {
    try {
      await tripAPI.cancelTrip(tripId, reason)
      dispatch({ type: "SET_CURRENT_TRIP", payload: null })
    } catch (error) {
      throw error
    }
  }

  const acceptTrip = async (tripId: number) => {
    try {
      const trip = await tripAPI.acceptTrip(tripId)
      dispatch({ type: "UPDATE_TRIP", payload: trip })
    } catch (error) {
      throw error
    }
  }

  const completeTrip = async (tripId: number) => {
    try {
      const trip = await tripAPI.completeTrip(tripId)
      dispatch({ type: "UPDATE_TRIP", payload: trip })
    } catch (error) {
      throw error
    }
  }

  const updateTripStatus = async (tripId: number, status: string) => {
    try {
      const trip = await tripAPI.updateTripStatus(tripId, status)
      dispatch({ type: "UPDATE_TRIP", payload: trip })
    } catch (error) {
      throw error
    }
  }

  const loadCurrentTrip = async () => {
    try {
      const trip = await tripAPI.getCurrentTrip()
      dispatch({ type: "SET_CURRENT_TRIP", payload: trip })
    } catch (error) {
      // No hay viaje actual, esto es normal
      dispatch({ type: "SET_CURRENT_TRIP", payload: null })
    }
  }

  const loadTripHistory = async () => {
    try {
      dispatch({ type: "SET_LOADING", payload: true })
      const trips = await tripAPI.getTripHistory()
      dispatch({ type: "SET_TRIP_HISTORY", payload: trips })
    } catch (error) {
      console.error("Error loading trip history:", error)
    } finally {
      dispatch({ type: "SET_LOADING", payload: false })
    }
  }

  const updateDriverLocation = (location: Location) => {
    dispatch({ type: "SET_DRIVER_LOCATION", payload: location })
  }

  return (
    <TripContext.Provider
      value={{
        ...state,
        requestTrip,
        cancelTrip,
        acceptTrip,
        completeTrip,
        updateTripStatus,
        loadCurrentTrip,
        loadTripHistory,
        updateDriverLocation,
      }}
    >
      {children}
    </TripContext.Provider>
  )
}

export const useTrip = () => {
  const context = useContext(TripContext)
  if (context === undefined) {
    throw new Error("useTrip must be used within a TripProvider")
  }
  return context
}
