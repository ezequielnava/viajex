-- Script para crear la base de datos MySQL
CREATE DATABASE IF NOT EXISTS mototaxi_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear usuario para la aplicación (opcional)
-- CREATE USER 'mototaxi_user'@'localhost' IDENTIFIED BY 'secure_password';
-- GRANT ALL PRIVILEGES ON mototaxi_db.* TO 'mototaxi_user'@'localhost';
-- FLUSH PRIVILEGES;

USE mototaxi_db;

-- Verificar que la base de datos fue creada correctamente
SELECT 'Base de datos mototaxi_db creada exitosamente' AS status;
