#!/usr/bin/env python3
"""
Script para ejecutar migraciones de Django
"""
import os
import sys
import django
from django.core.management import execute_from_command_line

def run_migrations():
    """Ejecuta las migraciones de Django"""
    
    # Configurar Django
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ride_app.settings')
    django.setup()
    
    print("🔄 Ejecutando migraciones de Django...")
    
    try:
        # Crear migraciones
        print("📝 Creando migraciones...")
        execute_from_command_line(['manage.py', 'makemigrations'])
        
        # Aplicar migraciones
        print("⚡ Aplicando migraciones...")
        execute_from_command_line(['manage.py', 'migrate'])
        
        print("✅ Migraciones completadas exitosamente!")
        
        # Crear superusuario si no existe
        print("👤 Verificando superusuario...")
        from django.contrib.auth import get_user_model
        User = get_user_model()
        
        if not User.objects.filter(is_superuser=True).exists():
            print("🔧 Creando superusuario por defecto...")
            User.objects.create_superuser(
                email='admin@mototaxi.com',
                password='admin123',
                first_name='Admin',
                last_name='User'
            )
            print("✅ Superusuario creado: admin@mototaxi.com / admin123")
        else:
            print("✅ Superusuario ya existe")
            
    except Exception as e:
        print(f"❌ Error ejecutando migraciones: {e}")
        sys.exit(1)

if __name__ == '__main__':
    run_migrations()
