"use client"

import ChatComponent from "../frontend/src/components/ChatComponent"

export default function SyntheticV0PageForDeployment() {
  return <ChatComponent />
}